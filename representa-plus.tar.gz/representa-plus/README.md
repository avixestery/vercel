# Representa+ — Next.js

Grêmio Estudantil — Colégio Ideal Batista Campos

## Estrutura

```
src/
  app/
    page.tsx          # Landing page principal
    admin/page.tsx    # Painel administrativo
    globals.css       # CSS global + design tokens
  components/
    Navbar.tsx
    Hero.tsx
    FormsSection.tsx  # Ideias + Ouvidoria
    AnunciosSection.tsx
    ProjetosSection.tsx
    FinanceiroSection.tsx
    CalendarioSection.tsx
    OtherSections.tsx # Equipe, Polls, Privacy, Contact, Footer
  lib/
    supabase.ts       # Client Supabase
```

## Rodar localmente

```bash
npm install
npm run dev
```

## Deploy GitHub Pages

```bash
npm run build
# Faça upload da pasta `out/` no GitHub Pages
```

## Deploy Vercel (recomendado)

1. Push para GitHub
2. Conecte no vercel.com
3. Deploy automático!

## Supabase

URL: https://qooqrmkhhnyziauwnhko.supabase.co

Execute os SQLs de setup antes de usar.
