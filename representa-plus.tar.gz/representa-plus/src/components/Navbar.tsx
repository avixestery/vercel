'use client'
import { useState } from 'react'
import Link from 'next/link'

const links = [
  { href: '#ideias', label: 'Ideias' },
  { href: '#ideias', label: 'Ouvidoria', tab: 'denuncia' },
  { href: '#anuncios', label: 'Anúncios' },
  { href: '#projetos', label: 'Projetos' },
  { href: '#financeiro', label: 'Financeiro' },
  { href: '#calendario', label: 'Calendário' },
  { href: '#equipe', label: 'Equipe' },
  { href: '#votacao', label: 'Votação' },
  { href: '#contato', label: 'Contato' },
]

interface NavbarProps {
  onOpenTab?: (tab: string) => void
}

export default function Navbar({ onOpenTab }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false)

  const handleClick = (tab?: string) => {
    if (tab && onOpenTab) onOpenTab(tab)
    setMobileOpen(false)
  }

  return (
    <>
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 1000,
        height: 64, padding: '0 28px',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        background: 'rgba(13,13,13,.95)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid var(--border)'
      }}>
        <a href="#home" style={{
          fontFamily: 'Syne, sans-serif', fontWeight: 800, fontSize: '1.3rem',
          color: 'var(--text)', textDecoration: 'none',
          display: 'flex', alignItems: 'center', gap: 10
        }}>
          <div style={{
            width: 32, height: 32, background: 'var(--red)', borderRadius: 8,
            display: 'grid', placeItems: 'center', fontSize: 16
          }}>✊</div>
          Representa<span style={{ color: 'var(--red)' }}>+</span>
        </a>

        {/* Desktop links */}
        <ul style={{ display: 'flex', alignItems: 'center', gap: 2, listStyle: 'none' }}
          className="hidden md:flex">
          {links.map((l) => (
            <li key={l.label}>
              <a href={l.href} onClick={() => handleClick(l.tab)}
                style={{ color: 'var(--text2)', textDecoration: 'none', fontSize: '.85rem', padding: '7px 12px', borderRadius: 8, fontWeight: 500, transition: 'var(--t)', display: 'block' }}
                onMouseEnter={e => { (e.target as HTMLElement).style.color = 'var(--text)'; (e.target as HTMLElement).style.background = 'var(--surface)'; }}
                onMouseLeave={e => { (e.target as HTMLElement).style.color = 'var(--text2)'; (e.target as HTMLElement).style.background = 'transparent'; }}>
                {l.label}
              </a>
            </li>
          ))}
          <li>
            <Link href="/admin" style={{
              background: 'var(--red)', color: '#fff', fontWeight: 600,
              padding: '7px 16px', borderRadius: 8, textDecoration: 'none', fontSize: '.85rem'
            }}>Admin ↗</Link>
          </li>
        </ul>

        {/* Hamburger */}
        <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}
          style={{ display: 'flex', flexDirection: 'column', gap: 5, cursor: 'pointer', padding: 8, background: 'none', border: 'none' }}>
          {[0,1,2].map(i => (
            <span key={i} style={{ display: 'block', width: 22, height: 2, background: 'var(--text)', borderRadius: 2 }} />
          ))}
        </button>
      </nav>

      {/* Mobile nav */}
      {mobileOpen && (
        <div style={{
          position: 'fixed', top: 64, left: 0, right: 0, zIndex: 999,
          background: 'rgba(13,13,13,.98)', backdropFilter: 'blur(20px)',
          borderBottom: '1px solid var(--border)', padding: '12px 20px 20px',
          display: 'flex', flexDirection: 'column', gap: 2
        }}>
          {links.map(l => (
            <a key={l.label} href={l.href} onClick={() => handleClick(l.tab)}
              style={{ display: 'block', color: 'var(--text2)', textDecoration: 'none', padding: '11px 14px', borderRadius: 8, fontSize: '.9rem', fontWeight: 500 }}>
              {l.label}
            </a>
          ))}
          <Link href="/admin" onClick={() => setMobileOpen(false)}
            style={{ display: 'block', color: 'var(--text2)', textDecoration: 'none', padding: '11px 14px', borderRadius: 8, fontSize: '.9rem', fontWeight: 500 }}>
            ⚙️ Admin
          </Link>
        </div>
      )}
    </>
  )
}
