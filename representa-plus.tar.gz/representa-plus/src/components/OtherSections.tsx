'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

// ── TEAM ──────────────────────────────────
const team = [
  { av: '👑', name: 'Luiz Henrique Diniz', role: 'Presidente', quote: '"Representa+ é sobre escutar antes de agir."' },
  { av: '🤝', name: 'Vinícius Pimentel', role: 'Vice-presidente', quote: '"Cada ideia tem potencial de mudar tudo."' },
  { av: '📋', name: 'Emanuele', role: 'Secretária', quote: '"Garantir que tudo funcione melhor amanhã."' },
  { av: '💰', name: 'Davi Portela', role: 'Diretor Financeiro', quote: '"Transparência nos recursos é respeito."' },
  { av: '🏐', name: 'Marina Barroso', role: 'Diretora de Esportes', quote: '"Aqui pra registrar cada conquista nossa."' },
  { av: '📣', name: 'Thayla e Giovanna', role: 'Diretoras de Comunicação', quote: '"Informação clara é poder para o aluno."' },
  { av: '🎭', name: 'Letícia', role: 'Diretora de Eventos', quote: '"Cada evento é uma memória que criamos juntos."' },
  { av: '🔬', name: 'Eduardo Sasaki', role: 'Diretor de Projetos', quote: '"Ideia boa sem execução não vale nada."' },
  { av: '🛡️', name: 'Analu Pantoja', role: 'Ouvidoria EF1 e EF2', quote: '"Nenhuma voz será silenciada aqui."' },
  { av: '🛡️', name: 'Bernardo Bandeira', role: 'Ouvidoria EM e MIL', quote: '"Nenhuma voz será silenciada aqui."' },
]

export function EquipeSection() {
  return (
    <div style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="equipe">
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Quem somos</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>A equipe Representa+</h2>
        <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7 }}>Alunos reais, comprometidos com você.</p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(200px,1fr))', gap: 14, marginTop: 36 }}>
          {team.map(m => (
            <div key={m.name} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: '24px 20px', textAlign: 'center', transition: 'var(--t)' }}>
              <div style={{ width: 62, height: 62, borderRadius: '50%', display: 'grid', placeItems: 'center', fontSize: '1.6rem', margin: '0 auto 12px', background: 'var(--bg3)', border: '2px solid var(--border)' }}>{m.av}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, marginBottom: 3 }}>{m.name}</div>
              <div style={{ fontSize: '.68rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.06em', color: 'var(--red)', marginBottom: 8 }}>{m.role}</div>
              <div style={{ fontSize: '.775rem', color: 'var(--text2)', lineHeight: 1.55, fontStyle: 'italic' }}>{m.quote}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ── POLLS ─────────────────────────────────
type Opcao = { id: string; texto: string; votos: number; ordem: number }
type Enquete = { id: string; pergunta: string; ativa: boolean; encerra_em: string | null; enquete_opcoes: Opcao[] }

export function PollsSection() {
  const [enq, setEnq] = useState<Enquete | null>(null)
  const [opcoes, setOpcoes] = useState<Opcao[]>([])
  const [sel, setSel] = useState<{ id: string; idx: number } | null>(null)
  const [voted, setVoted] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('enquetes').select('*,enquete_opcoes(*)').eq('ativa', true)
      .order('created_at', { ascending: false }).limit(1).single()
      .then(({ data }) => {
        if (data) {
          setEnq(data as Enquete)
          const sorted = [...(data.enquete_opcoes || [])].sort((a, b) => a.ordem - b.ordem)
          setOpcoes(sorted)
          setVoted(localStorage.getItem('voted_' + data.id) === 'true')
        }
        setLoading(false)
      })
  }, [])

  async function confirmVote() {
    if (!sel || !enq || voted) return
    const opt = opcoes.find(o => o.id === sel.id)
    if (!opt) return
    await supabase.from('enquete_opcoes').update({ votos: opt.votos + 1 }).eq('id', sel.id)
    localStorage.setItem('voted_' + enq.id, 'true')
    localStorage.setItem('voted_opt_' + enq.id, sel.id)
    setVoted(true)
    setOpcoes(prev => prev.map(o => o.id === sel.id ? { ...o, votos: o.votos + 1 } : o))
  }

  const tot = opcoes.reduce((a, o) => a + o.votos, 0) || 1

  return (
    <div style={{ borderTop: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="votacao">
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Democracia ativa</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>Vote. Decida junto.</h2>
        <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7 }}>Suas escolhas moldam o grêmio. Cada voto conta — literalmente.</p>

        <div style={{ maxWidth: 660, margin: '0 auto' }}>
          {loading ? <div className="skel" style={{ height: 280, borderRadius: 16, marginTop: 32 }} /> :
            !enq ? <div style={{ textAlign: 'center', padding: 40, color: 'var(--text3)' }}>Nenhuma enquete ativa no momento.</div> : (
              <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 32, marginTop: 32 }}>
                <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.35rem', fontWeight: 800, lineHeight: 1.2, marginBottom: 6 }}>{enq.pergunta}</div>
                <div style={{ fontSize: '.78rem', color: 'var(--text3)', marginBottom: 26 }}>{voted ? 'Você já votou. Obrigado!' : 'Escolha uma opção · Resultados em tempo real'}</div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: 9, marginBottom: 18 }}>
                  {opcoes.map((o, i) => {
                    const pct = Math.round(o.votos / tot * 100)
                    const isSel = sel?.idx === i || (voted && localStorage.getItem('voted_opt_' + enq.id) === o.id)
                    return (
                      <div key={o.id} onClick={() => !voted && setSel({ id: o.id, idx: i })}
                        style={{ position: 'relative', border: `1px solid ${isSel ? 'var(--red)' : 'var(--border)'}`, borderRadius: 10, overflow: 'hidden', cursor: voted ? 'default' : 'pointer' }}>
                        <div className="poll-fill" style={{ width: `${pct}%` }} />
                        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px' }}>
                          <span style={{ fontSize: '.9rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 9 }}>
                            <span style={{ width: 16, height: 16, border: `2px solid ${isSel ? 'var(--red)' : 'var(--border)'}`, borderRadius: '50%', background: isSel ? 'var(--red)' : 'transparent', boxShadow: isSel ? 'inset 0 0 0 3px var(--surface)' : 'none', flexShrink: 0 }} />
                            {o.texto}
                          </span>
                          <span style={{ fontSize: '.82rem', fontWeight: 700, color: 'var(--red)' }}>{pct}%</span>
                        </div>
                      </div>
                    )
                  })}
                </div>

                <button onClick={confirmVote} disabled={voted || !sel}
                  style={{ width: '100%', padding: 13, background: 'var(--red)', color: '#fff', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, cursor: (voted || !sel) ? 'not-allowed' : 'pointer', opacity: (voted || !sel) ? .4 : 1, marginBottom: 12 }}>
                  {voted ? '✓ Voto registrado!' : 'Confirmar voto →'}
                </button>
                <div style={{ fontSize: '.73rem', color: 'var(--text3)', textAlign: 'center' }}>🗳️ {tot} votos</div>
              </div>
            )
          }
        </div>
      </div>
    </div>
  )
}

// ── PRIVACY ───────────────────────────────
export function PrivacySection({ onOpenTab }: { onOpenTab: (t: string) => void }) {
  return (
    <div style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }}>
        <div style={{ textAlign: 'center', marginBottom: 28 }}>
          <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Segurança</div>
          <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>Seguro. Anônimo. Confiável.</h2>
          <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7, margin: '0 auto' }}>Sua privacidade não é negociável.</p>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 36 }} className="priv-grid">
          <div style={{ gridColumn: '1/-1', background: 'linear-gradient(135deg,rgba(232,25,44,.06),rgba(232,25,44,.02))', border: '1px solid rgba(232,25,44,.22)', borderRadius: 14, padding: '26px 30px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 20, flexWrap: 'wrap' }}>
            <div>
              <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.25rem', fontWeight: 800, marginBottom: 6 }}>🔐 Denúncias protegidas por padrão</h3>
              <p style={{ fontSize: '.855rem', color: 'var(--text2)', maxWidth: 420 }}>Todas as denúncias chegam sem identificação. Nem o grêmio sabe quem enviou.</p>
            </div>
            <a href="#ideias" onClick={() => onOpenTab('denuncia')}
              style={{ padding: '12px 22px', borderRadius: 10, background: 'var(--red)', color: '#fff', fontWeight: 600, textDecoration: 'none', fontSize: '.9rem', whiteSpace: 'nowrap' }}>
              Fazer denúncia →
            </a>
          </div>
          {[
            { icon: '🚫', title: 'Sem coleta de dados', text: 'Não registramos nenhum dado pessoal nas denúncias e mensagens anônimas.' },
            { icon: '🗑️', title: 'Dados não compartilhados', text: 'Nenhuma informação pessoal compartilhada sem sua autorização.' },
            { icon: '🛡️', title: 'Proteção contra spam', text: 'Sistema de proteção evita abusos do canal de ouvidoria.' },
            { icon: '⚖️', title: 'Uso responsável', text: 'Denúncias falsas e mal-intencionadas podem ter consequências disciplinares.' },
          ].map(f => (
            <div key={f.title} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 22, display: 'flex', gap: 12, alignItems: 'flex-start' }}>
              <div style={{ fontSize: '1.6rem', flexShrink: 0 }}>{f.icon}</div>
              <div>
                <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, marginBottom: 4 }}>{f.title}</h3>
                <p style={{ fontSize: '.8rem', color: 'var(--text2)', lineHeight: 1.6 }}>{f.text}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
      <style>{`@media(max-width:768px){.priv-grid{grid-template-columns:1fr!important;}}`}</style>
    </div>
  )
}

// ── CONTACT ───────────────────────────────
export function ContactSection() {
  const [nome, setNome] = useState('')
  const [email, setEmail] = useState('')
  const [msg, setMsg] = useState('')
  const [ok, setOk] = useState(false)
  const [loading, setLoading] = useState(false)
  const [toast, setToast] = useState<{ icon: string; text: string } | null>(null)

  function showToast(icon: string, text: string) {
    setToast({ icon, text }); setTimeout(() => setToast(null), 3200)
  }

  async function submit() {
    if (!nome.trim()) { showToast('⚠️', 'Informe seu nome!'); return }
    if (!msg.trim()) { showToast('⚠️', 'Escreva uma mensagem!'); return }
    setLoading(true)
    const { error } = await supabase.from('contatos').insert({ nome, email: email || null, mensagem: msg })
    setLoading(false)
    if (error) { showToast('❌', 'Erro ao enviar. Tente novamente.'); return }
    setOk(true); showToast('📩', 'Mensagem enviada!')
  }

  const inp: React.CSSProperties = { width: '100%', background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, padding: '11px 14px', color: 'var(--text)', fontFamily: 'DM Sans, sans-serif', fontSize: '.9rem', outline: 'none' }

  return (
    <div style={{ borderTop: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="contato">
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Fale conosco</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 36 }}>Contato direto</h2>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 52, alignItems: 'start' }} className="contact-grid">
          <div>
            <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.4rem', fontWeight: 800, marginBottom: 8 }}>A gente responde.</h3>
            <p style={{ color: 'var(--text2)', fontSize: '.9rem', lineHeight: 1.7, marginBottom: 24, fontWeight: 300 }}>Tem uma dúvida ou sugestão? Manda mensagem. O Representa+ está aqui para isso.</p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { icon: '📸', label: 'Instagram', handle: '@representamais.ideal', href: 'https://instagram.com/representamais.ideal' },
                { icon: '💬', label: 'WhatsApp', handle: 'Grupo do grêmio', href: '#' },
                { icon: '📧', label: 'E-mail', handle: 'gremio@ibc.edu.br', href: 'mailto:gremio@ibc.edu.br' },
                { icon: '📍', label: 'Presencial', handle: 'Sala do grêmio — bloco Militar', href: '#' },
              ].map(s => (
                <a key={s.label} href={s.href} target={s.href.startsWith('http') ? '_blank' : undefined} rel="noreferrer"
                  style={{ display: 'flex', alignItems: 'center', gap: 11, padding: '12px 14px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, textDecoration: 'none', color: 'var(--text)', fontSize: '.835rem', fontWeight: 500 }}>
                  <span style={{ fontSize: '1.1rem' }}>{s.icon}</span>
                  <span>{s.label}</span>
                  <span style={{ marginLeft: 'auto', color: 'var(--text3)', fontSize: '.75rem' }}>{s.handle}</span>
                </a>
              ))}
            </div>
          </div>

          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 30 }}>
            {ok ? (
              <div style={{ textAlign: 'center', padding: '32px 12px' }}>
                <span style={{ fontSize: '2.6rem', display: 'block', marginBottom: 12 }}>📩</span>
                <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.25rem', fontWeight: 700, marginBottom: 6 }}>Mensagem enviada!</h3>
                <p style={{ color: 'var(--text2)', fontSize: '.855rem' }}>Vamos responder em breve!</p>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                <div><label style={{ display: 'block', fontSize: '.8rem', fontWeight: 600, color: 'var(--text2)', marginBottom: 6 }}>Seu nome</label><input style={inp} value={nome} onChange={e => setNome(e.target.value)} placeholder="Como podemos te chamar?" /></div>
                <div><label style={{ display: 'block', fontSize: '.8rem', fontWeight: 600, color: 'var(--text2)', marginBottom: 6 }}>E-mail <span style={{ fontSize: '.65rem', color: 'var(--text3)', background: 'var(--bg3)', padding: '2px 6px', borderRadius: 4, marginLeft: 5 }}>opcional</span></label><input style={inp} value={email} onChange={e => setEmail(e.target.value)} placeholder="Para te respondermos" /></div>
                <div><label style={{ display: 'block', fontSize: '.8rem', fontWeight: 600, color: 'var(--text2)', marginBottom: 6 }}>Mensagem</label><textarea style={{ ...inp, minHeight: 110, resize: 'vertical' }} value={msg} onChange={e => setMsg(e.target.value)} placeholder="Pode mandar — estamos aqui pra ouvir." /></div>
                <button onClick={submit} disabled={loading}
                  style={{ width: '100%', padding: 13, background: 'var(--red)', color: '#fff', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, cursor: loading ? 'not-allowed' : 'pointer', opacity: loading ? .5 : 1 }}>
                  {loading ? 'Enviando...' : 'Enviar mensagem →'}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {toast && (
        <div style={{ position: 'fixed', bottom: 20, right: 20, background: 'var(--surface)', border: '1px solid rgba(232,25,44,.35)', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, zIndex: 5000, boxShadow: '0 8px 28px rgba(0,0,0,.5)' }}>
          <span>{toast.icon}</span><span style={{ fontSize: '.84rem', fontWeight: 500 }}>{toast.text}</span>
        </div>
      )}
      <style>{`@media(max-width:768px){.contact-grid{grid-template-columns:1fr!important;}}`}</style>
    </div>
  )
}

// ── FOOTER ────────────────────────────────
export function Footer() {
  return (
    <footer style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', padding: '40px 24px', textAlign: 'center' }}>
      <div style={{ width: 50, height: 3, background: 'var(--red)', borderRadius: 100, margin: '0 auto 24px' }} />
      <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.3rem', fontWeight: 800, marginBottom: 6 }}>Representa<span style={{ color: 'var(--red)' }}>+</span></div>
      <div style={{ fontSize: '.8rem', color: 'var(--text3)', marginBottom: 18 }}>Um grêmio feito por alunos, para alunos · 🏫 Escola Ideal Batista Campos</div>
      <div style={{ display: 'flex', gap: 20, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 22 }}>
        {['#home','#ideias','#anuncios','#projetos','#calendario','#equipe','#votacao','#contato'].map(h => (
          <a key={h} href={h} style={{ color: 'var(--text3)', textDecoration: 'none', fontSize: '.8rem' }}>
            {h.replace('#', '').charAt(0).toUpperCase() + h.replace('#', '').slice(1)}
          </a>
        ))}
        <a href="/admin" style={{ color: 'var(--text3)', textDecoration: 'none', fontSize: '.8rem' }}>Admin</a>
      </div>
      <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>© 2025 Grêmio Estudantil Representa+ — Escola Ideal Batista Campos</div>
    </footer>
  )
}
