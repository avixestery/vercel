'use client'
import { useState, useRef } from 'react'
import { supabase } from '@/lib/supabase'

type Tab = 'ideas' | 'denuncia'

interface FormsSectionProps {
  activeTab: Tab
  setActiveTab: (t: Tab) => void
}

function useToast() {
  const [msg, setMsg] = useState<{ icon: string; text: string } | null>(null)
  const show = (icon: string, text: string) => {
    setMsg({ icon, text })
    setTimeout(() => setMsg(null), 3200)
  }
  return { msg, show }
}

export default function FormsSection({ activeTab, setActiveTab }: FormsSectionProps) {
  const { msg, show } = useToast()

  // Ideia state
  const [ideiaNome, setIdeiaNome] = useState('')
  const [ideiaCategoria, setIdeiaCategoria] = useState('')
  const [ideiaTexto, setIdeiaTexto] = useState('')
  const [ideiaAnon, setIdeiaAnon] = useState(false)
  const [ideiaOk, setIdeiaOk] = useState(false)
  const [ideiaLoading, setIdeiaLoading] = useState(false)

  // Denúncia state
  const [denCat, setDenCat] = useState('')
  const [denTexto, setDenTexto] = useState('')
  const [denOk, setDenOk] = useState(false)
  const [denLoading, setDenLoading] = useState(false)

  async function submitIdeia() {
    if (!ideiaTexto.trim()) { show('⚠️', 'Escreva sua ideia!'); return }
    if (!ideiaCategoria) { show('⚠️', 'Selecione uma categoria!'); return }
    setIdeiaLoading(true)
    const { error } = await supabase.from('ideias').insert({
      nome: ideiaAnon ? null : (ideiaNome || null),
      categoria: ideiaCategoria, texto: ideiaTexto, anonimo: ideiaAnon
    })
    setIdeiaLoading(false)
    if (error) { show('❌', 'Erro ao enviar. Tente novamente.'); return }
    setIdeiaOk(true)
    show('💡', 'Ideia enviada com sucesso!')
  }

  async function submitDenuncia() {
    if (!denTexto.trim()) { show('⚠️', 'Descreva a situação!'); return }
    setDenLoading(true)
    const { error } = await supabase.from('denuncias').insert({
      categoria: denCat || 'não especificado', texto: denTexto
    })
    setDenLoading(false)
    if (error) { show('❌', 'Erro ao enviar. Tente novamente.'); return }
    setDenOk(true)
    show('🔒', 'Denúncia registrada com sigilo!')
  }

  return (
    <div className="alt-bg" id="ideias" style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 56, alignItems: 'center' }}
          className="form-grid-responsive">

          {/* Info */}
          <div>
            <div style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 12px', borderRadius: 100, fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.08em', marginBottom: 14, background: 'var(--red-subtle)', color: 'var(--red-light)', border: '1px solid rgba(232,25,44,.25)' }}>
              💡 Sua voz importa
            </div>
            <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.7rem,3vw,2.5rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>
              Fala aí,<br />a gente escuta.
            </h2>
            <p style={{ color: 'var(--text2)', fontSize: '.93rem', lineHeight: 1.7, marginBottom: 24, fontWeight: 300 }}>
              Tem uma ideia pra melhorar a escola? Quer fazer uma denúncia com sigilo total? Simples, rápido e direto.
            </p>
            <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 10 }}>
              {['Anonimato opcional nas ideias','Todas as sugestões são analisadas','Categorização por área','Feedback sobre sua ideia','Sistema contra spam'].map(f => (
                <li key={f} style={{ display: 'flex', alignItems: 'center', gap: 9, fontSize: '.855rem', color: 'var(--text2)' }}>
                  <span style={{ width: 18, height: 18, borderRadius: '50%', background: 'var(--red-subtle)', border: '1px solid rgba(232,25,44,.3)', display: 'grid', placeItems: 'center', color: 'var(--red)', fontSize: 10, flexShrink: 0 }}>✓</span>
                  {f}
                </li>
              ))}
            </ul>
          </div>

          {/* Card */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 30 }}>
            {/* Tabs */}
            <div style={{ display: 'flex', gap: 4, background: 'var(--bg3)', padding: 4, borderRadius: 10, marginBottom: 22 }}>
              {(['ideas', 'denuncia'] as Tab[]).map(t => (
                <button key={t} onClick={() => setActiveTab(t)}
                  style={{ flex: 1, padding: '9px 12px', border: 'none', borderRadius: 7, fontFamily: 'DM Sans, sans-serif', fontSize: '.83rem', fontWeight: 600, cursor: 'pointer', transition: 'var(--t)', background: activeTab === t ? 'var(--surface2)' : 'transparent', color: activeTab === t ? 'var(--text)' : 'var(--text2)' }}>
                  {t === 'ideas' ? '💡 Ideia / Sugestão' : '⚠️ Denúncia'}
                </button>
              ))}
            </div>

            {/* Ideas tab */}
            {activeTab === 'ideas' && (
              ideiaOk ? (
                <div style={{ textAlign: 'center', padding: '32px 12px' }}>
                  <span style={{ fontSize: '2.6rem', display: 'block', marginBottom: 12 }}>🎉</span>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.25rem', fontWeight: 700, marginBottom: 6 }}>Ideia recebida!</h3>
                  <p style={{ color: 'var(--text2)', fontSize: '.855rem' }}>Sua sugestão foi registrada e será analisada pelo grêmio.</p>
                  <button onClick={() => { setIdeiaOk(false); setIdeiaTexto(''); setIdeiaNome(''); setIdeiaCategoria(''); setIdeiaAnon(false); }}
                    style={{ marginTop: 12, padding: '7px 14px', borderRadius: 8, fontSize: '.78rem', fontWeight: 600, cursor: 'pointer', background: 'var(--surface)', color: 'var(--text)', border: '1px solid var(--border)' }}>
                    Enviar outra
                  </button>
                </div>
              ) : (
                <div>
                  <Field label="Nome" optional>
                    <input value={ideiaNome} onChange={e => setIdeiaNome(e.target.value)} className="form-input-styled" placeholder="Seu nome (ou deixe em branco)" />
                  </Field>
                  <Field label="Categoria">
                    <select value={ideiaCategoria} onChange={e => setIdeiaCategoria(e.target.value)} className="form-input-styled">
                      <option value="">Escolha uma categoria...</option>
                      <option value="eventos">🎉 Eventos</option>
                      <option value="melhorias">🔧 Melhorias na escola</option>
                      <option value="ensino">📚 Ensino e aulas</option>
                      <option value="estrutura">🏗️ Estrutura física</option>
                      <option value="cultura">🎭 Cultura e lazer</option>
                      <option value="outros">✨ Outros</option>
                    </select>
                  </Field>
                  <Field label="Sua ideia">
                    <textarea value={ideiaTexto} onChange={e => setIdeiaTexto(e.target.value)} className="form-input-styled" placeholder="Descreva sua ideia com detalhes..." style={{ minHeight: 110, resize: 'vertical' }} />
                  </Field>
                  <label onClick={() => setIdeiaAnon(!ideiaAnon)} style={{ display: 'flex', alignItems: 'center', gap: 11, background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 8, padding: '11px 14px', cursor: 'pointer', marginBottom: 4 }}>
                    <div style={{ position: 'relative', width: 38, height: 20, flexShrink: 0 }}>
                      <input type="checkbox" checked={ideiaAnon} readOnly style={{ display: 'none' }} />
                      <div className="toggle-track" style={{ background: ideiaAnon ? 'var(--red)' : 'var(--border)' }} />
                      <div className="toggle-thumb" style={{ transform: ideiaAnon ? 'translateX(18px)' : 'none' }} />
                    </div>
                    <span style={{ fontSize: '.855rem', fontWeight: 600 }}>Enviar anonimamente</span>
                    <span style={{ fontSize: '.7rem', color: 'var(--text3)', marginLeft: 'auto' }}>Sem coleta de IP</span>
                  </label>
                  <button onClick={submitIdeia} disabled={ideiaLoading}
                    style={{ width: '100%', padding: 13, background: 'var(--red)', color: '#fff', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, cursor: ideiaLoading ? 'not-allowed' : 'pointer', marginTop: 10, opacity: ideiaLoading ? .5 : 1 }}>
                    {ideiaLoading ? 'Enviando...' : 'Enviar ideia →'}
                  </button>
                </div>
              )
            )}

            {/* Denuncia tab */}
            {activeTab === 'denuncia' && (
              denOk ? (
                <div style={{ textAlign: 'center', padding: '32px 12px' }}>
                  <span style={{ fontSize: '2.6rem', display: 'block', marginBottom: 12 }}>🔒</span>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.25rem', fontWeight: 700, marginBottom: 6 }}>Mensagem recebida</h3>
                  <p style={{ color: 'var(--text2)', fontSize: '.855rem' }}>Sua denúncia foi registrada com total sigilo.</p>
                  <button onClick={() => { setDenOk(false); setDenTexto(''); setDenCat(''); }}
                    style={{ marginTop: 12, padding: '7px 14px', borderRadius: 8, fontSize: '.78rem', fontWeight: 600, cursor: 'pointer', background: 'var(--surface)', color: 'var(--text)', border: '1px solid var(--border)' }}>
                    Enviar outra
                  </button>
                </div>
              ) : (
                <div>
                  <div style={{ background: 'rgba(232,25,44,.07)', border: '1px solid rgba(232,25,44,.2)', borderRadius: 8, padding: '12px 14px', marginBottom: 16, display: 'flex', gap: 10 }}>
                    <span>🔒</span>
                    <div>
                      <div style={{ fontSize: '.8rem', fontWeight: 600, color: 'var(--red-light)', marginBottom: 2 }}>Canal 100% anônimo</div>
                      <div style={{ fontSize: '.73rem', color: 'var(--text3)', lineHeight: 1.5 }}>Não coletamos dados pessoais nem IPs.</div>
                    </div>
                  </div>
                  <Field label="Tipo de situação">
                    <select value={denCat} onChange={e => setDenCat(e.target.value)} className="form-input-styled">
                      <option value="">Selecione o tipo...</option>
                      <option value="bullying">😔 Bullying ou assédio</option>
                      <option value="violencia">⚠️ Violência</option>
                      <option value="discriminacao">🤝 Discriminação</option>
                      <option value="estrutura">🏗️ Problema de estrutura</option>
                      <option value="outros">📝 Outro</option>
                    </select>
                  </Field>
                  <Field label="Descreva a situação">
                    <textarea value={denTexto} onChange={e => setDenTexto(e.target.value)} className="form-input-styled" placeholder="Descreva o que aconteceu. Local, horário, envolvidos..." style={{ minHeight: 110, resize: 'vertical' }} />
                  </Field>
                  <div style={{ fontSize: '.72rem', color: 'var(--text3)', marginBottom: 14, lineHeight: 1.55 }}>⚠️ Denúncias graves serão encaminhadas à coordenação.</div>
                  <button onClick={submitDenuncia} disabled={denLoading}
                    style={{ width: '100%', padding: 13, background: 'var(--red)', color: '#fff', border: 'none', borderRadius: 10, fontFamily: 'Syne, sans-serif', fontSize: '.93rem', fontWeight: 700, cursor: denLoading ? 'not-allowed' : 'pointer', opacity: denLoading ? .5 : 1 }}>
                    {denLoading ? 'Enviando...' : 'Enviar denúncia →'}
                  </button>
                </div>
              )
            )}
          </div>
        </div>
      </div>

      {/* Toast */}
      {msg && (
        <div style={{ position: 'fixed', bottom: 20, right: 20, background: 'var(--surface)', border: '1px solid rgba(232,25,44,.35)', borderRadius: 10, padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10, zIndex: 5000, boxShadow: '0 8px 28px rgba(0,0,0,.5)' }}>
          <span>{msg.icon}</span>
          <span style={{ fontSize: '.84rem', fontWeight: 500 }}>{msg.text}</span>
        </div>
      )}

      <style>{`
        .form-input-styled { width:100%;background:var(--bg3);border:1px solid var(--border);border-radius:8px;padding:11px 14px;color:var(--text);font-family:'DM Sans',sans-serif;font-size:.9rem;transition:var(--t);outline:none;appearance:none; }
        .form-input-styled:focus { border-color:var(--red);box-shadow:0 0 0 3px rgba(232,25,44,.1); }
        @media(max-width:768px){ .form-grid-responsive { grid-template-columns:1fr !important; } }
      `}</style>
    </div>
  )
}

function Field({ label, optional, children }: { label: string; optional?: boolean; children: React.ReactNode }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: 'block', fontSize: '.8rem', fontWeight: 600, color: 'var(--text2)', marginBottom: 6 }}>
        {label}
        {optional && <span style={{ fontSize: '.65rem', color: 'var(--text3)', background: 'var(--bg3)', padding: '2px 6px', borderRadius: 4, marginLeft: 5 }}>opcional</span>}
      </label>
      {children}
    </div>
  )
}
