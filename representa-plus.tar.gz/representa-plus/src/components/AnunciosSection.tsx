'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Anuncio = { id: string; titulo: string; descricao: string; categoria: string; destaque: boolean; autor: string; created_at: string }

const tagStyle: Record<string, React.CSSProperties> = {
  evento: { background: 'rgba(232,25,44,.12)', color: 'var(--red-light)' },
  aviso:  { background: 'rgba(245,166,35,.12)', color: 'var(--gold)' },
  campanha: { background: 'rgba(255,255,255,.07)', color: 'var(--text2)' },
  urgente: { background: 'rgba(232,25,44,.2)', color: 'var(--red-light)', border: '1px solid rgba(232,25,44,.25)' },
}

export default function AnunciosSection() {
  const [anuncios, setAnuncios] = useState<Anuncio[]>([])
  const [loading, setLoading] = useState(true)
  const [filter, setFilter] = useState('all')

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('anuncios').select('*').eq('publicado', true)
        .order('destaque', { ascending: false }).order('created_at', { ascending: false })
      setAnuncios(data || [])
      setLoading(false)
    }
    load()
  }, [])

  const visible = filter === 'all' ? anuncios : anuncios.filter(a => a.categoria === filter)

  return (
    <div style={{ borderTop: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="anuncios">
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 28, flexWrap: 'wrap', gap: 16 }}>
          <div>
            <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Feed de notícias</div>
            <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em' }}>Anúncios e<br />comunicados</h2>
          </div>
          <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
            {['all','evento','aviso','campanha'].map(f => (
              <button key={f} onClick={() => setFilter(f)}
                style={{ padding: '6px 14px', borderRadius: 100, border: '1px solid var(--border)', background: filter === f ? 'var(--red)' : 'transparent', color: filter === f ? '#fff' : 'var(--text2)', fontFamily: 'DM Sans, sans-serif', fontSize: '.75rem', fontWeight: 600, cursor: 'pointer' }}>
                {f === 'all' ? 'Todos' : f.charAt(0).toUpperCase() + f.slice(1)}s
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div className="skel" style={{ height: 160 }} />
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div className="skel" style={{ height: 120 }} />
              <div className="skel" style={{ height: 120 }} />
            </div>
          </div>
        ) : visible.length === 0 ? (
          <div style={{ textAlign: 'center', padding: 40, color: 'var(--text3)' }}>Nenhum anúncio publicado ainda.</div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(290px,1fr))', gap: 14 }}>
            {visible.map((a, i) => {
              const fmt = new Date(a.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' })
              const isFeature = a.destaque && i === 0 && filter === 'all'
              return (
                <div key={a.id}
                  style={{
                    background: isFeature ? 'linear-gradient(135deg,rgba(232,25,44,.05),var(--surface))' : 'var(--surface)',
                    border: isFeature ? '1px solid rgba(232,25,44,.2)' : '1px solid var(--border)',
                    borderRadius: 14, padding: 24, transition: 'var(--t)',
                    gridColumn: isFeature ? '1 / -1' : undefined,
                    display: isFeature ? 'grid' : 'block',
                    gridTemplateColumns: isFeature ? '1fr auto' : undefined,
                    gap: isFeature ? 20 : undefined,
                    alignItems: isFeature ? 'center' : undefined,
                  }}>
                  <div>
                    {isFeature && <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: 'rgba(232,25,44,.15)', color: 'var(--red-light)', fontSize: '.67rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', padding: '3px 9px', borderRadius: 100, marginBottom: 8 }}>⭐ Destaque</div>}
                    <div style={{ display: 'inline-block', fontSize: '.65rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.07em', padding: '3px 8px', borderRadius: 5, marginBottom: 8, ...(tagStyle[a.categoria] || tagStyle.aviso) }}>
                      {a.categoria.charAt(0).toUpperCase() + a.categoria.slice(1)}
                    </div>
                    <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1rem', fontWeight: 700, marginBottom: 6, lineHeight: 1.3 }}>{a.titulo}</h3>
                    <p style={{ fontSize: '.835rem', color: 'var(--text2)', lineHeight: 1.6, marginBottom: 12 }}>{a.descricao}</p>
                    <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>📅 {fmt} · {a.autor}</div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}
