'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Projeto = { id: string; nome: string; descricao: string; status: string; progresso: number; voluntarios: number; max_participantes: number; sem_participantes: boolean }

const stMap: Record<string, [string, string]> = {
  planejamento: ['rgba(245,166,35,.12)', 'var(--gold)'],
  andamento: ['var(--red-subtle)', 'var(--red-light)'],
  concluido: ['rgba(255,255,255,.07)', '#aaa'],
}
const stLabel: Record<string, string> = { planejamento: 'Em planejamento', andamento: 'Em andamento', concluido: 'Concluído' }

export default function ProjetosSection() {
  const [projetos, setProjetos] = useState<Projeto[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    supabase.from('projetos').select('*').order('ordem').then(({ data }) => {
      setProjetos(data || [])
      setLoading(false)
    })
  }, [])

  return (
    <div style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="projetos">
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Em andamento</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>Projetos<br />do grêmio</h2>
        <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7 }}>Transparência é a base. Acompanhe tudo que estamos fazendo pela escola.</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(280px,1fr))', gap: 14, marginTop: 36 }}>
          {loading ? [1,2,3].map(i => <div key={i} className="skel" style={{ height: 200 }} />) :
            projetos.length === 0 ? <div style={{ color: 'var(--text3)', textAlign: 'center', padding: 32, gridColumn: '1/-1' }}>Nenhum projeto cadastrado ainda.</div> :
            projetos.map(p => {
              const [bg, color] = stMap[p.status] || stMap.planejamento
              let participLine = ''
              if (!p.sem_participantes) {
                const parts = []
                if (p.voluntarios > 0) parts.push(`${p.voluntarios} voluntário${p.voluntarios !== 1 ? 's' : ''}`)
                if (p.max_participantes > 0) parts.push(`máx. ${p.max_participantes} participantes`)
                if (parts.length) participLine = parts.join(' · ')
              }
              return (
                <div key={p.id} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 24, transition: 'var(--t)' }}>
                  <div style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '4px 11px', borderRadius: 100, fontSize: '.7rem', fontWeight: 700, marginBottom: 12, background: bg, color }}>
                    <span style={{ width: 5, height: 5, borderRadius: '50%', background: 'currentColor' }} />
                    {stLabel[p.status]}
                  </div>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.05rem', fontWeight: 700, marginBottom: 7 }}>{p.nome}</h3>
                  <p style={{ fontSize: '.835rem', color: 'var(--text2)', lineHeight: 1.6, marginBottom: 14 }}>{p.descricao}</p>
                  <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.7rem', color: 'var(--text3)', marginBottom: 5 }}>
                    <span>Progresso</span><span>{p.progresso}%</span>
                  </div>
                  <div style={{ height: 3, background: 'var(--bg3)', borderRadius: 100, overflow: 'hidden', marginBottom: 14 }}>
                    <div className="prog-fill" style={{ height: '100%', borderRadius: 100, background: 'var(--red)', width: `${p.progresso}%` }} />
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    {participLine ? <span style={{ fontSize: '.72rem', color: 'var(--text3)' }}>{participLine}</span> : <span />}
                    <a href="#" style={{ padding: '7px 14px', fontSize: '.78rem', fontWeight: 600, borderRadius: 8, background: 'var(--surface)', color: 'var(--text)', border: '1px solid var(--border)', textDecoration: 'none' }}>Acompanhar</a>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
    </div>
  )
}
