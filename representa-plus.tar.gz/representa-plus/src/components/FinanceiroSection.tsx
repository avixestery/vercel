'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Mov = { id: string; tipo: string; descricao: string; valor: number; categoria: string; data: string; projeto_ref: string | null }
type Meta = { id: string; nome: string; meta: number; descricao: string | null }

const catIcon: Record<string, string> = { arrecadacao:'🎪',doacao:'🤝',evento:'🎉',projeto:'🚀',material:'📦',servico:'🔧',outros:'📌' }

function fmtBRL(v: number) { return 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 0, maximumFractionDigits: 0 }) }
function fmtFull(v: number) { return 'R$ ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) }

export default function FinanceiroSection() {
  const [movs, setMovs] = useState<Mov[]>([])
  const [metas, setMetas] = useState<Meta[]>([])
  const [filter, setFilter] = useState('all')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      supabase.from('financeiro').select('*').eq('publicado', true).order('data', { ascending: false }),
      supabase.from('metas_financeiras').select('*').eq('ativa', true),
    ]).then(([{ data: m }, { data: mt }]) => {
      setMovs(m || [])
      setMetas(mt || [])
      setLoading(false)
    })
  }, [])

  const entradas = movs.filter(m => m.tipo === 'entrada')
  const saidas   = movs.filter(m => m.tipo === 'saida')
  const totalEnt = entradas.reduce((a, m) => a + Number(m.valor), 0)
  const totalSai = saidas.reduce((a, m) => a + Number(m.valor), 0)
  const totalMeta = metas.reduce((a, m) => a + Number(m.meta), 0)
  const visible = filter === 'all' ? movs : movs.filter(m => m.tipo === filter)

  const totals = [
    { label: 'TOTAL ARRECADADO', value: fmtBRL(totalEnt), sub: `${entradas.length} entradas`, color: 'var(--green)' },
    { label: 'TOTAL GASTO', value: fmtBRL(totalSai), sub: `${saidas.length} saídas`, color: 'var(--red)' },
    { label: 'SALDO DISPONÍVEL', value: fmtBRL(totalEnt - totalSai), sub: 'em caixa', color: 'var(--text)' },
    { label: 'META TOTAL', value: fmtBRL(totalMeta), sub: 'todos os projetos', color: 'var(--gold)' },
  ]

  return (
    <div id="financeiro" style={{ background: 'var(--bg2)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }}>
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Prestação de contas</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>
          Transparência<br /><span style={{ color: 'var(--red)' }}>Financeira</span>
        </h2>
        <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7, marginBottom: 32 }}>
          Todos os recursos arrecadados, gastos realizados e metas dos projetos — atualizados para a comunidade escolar.
        </p>

        {/* Totals grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 28 }} className="fin-totals-grid">
          {totals.map(t => (
            <div key={t.label} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 12, padding: '20px 22px' }}>
              <div style={{ fontSize: '.65rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.1em', color: 'var(--text3)', marginBottom: 10 }}>{t.label}</div>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.7rem', fontWeight: 800, lineHeight: 1, marginBottom: 6, color: t.color }}>{loading ? '—' : t.value}</div>
              <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>{t.sub}</div>
            </div>
          ))}
        </div>

        {/* Body: moves + goals */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 300px', gap: 20, alignItems: 'start' }} className="fin-body-grid">
          <div>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12, flexWrap: 'wrap', gap: 8 }}>
              <span style={{ fontFamily: 'Syne, sans-serif', fontSize: '.95rem', fontWeight: 700 }}>Movimentações</span>
              <div style={{ display: 'flex', gap: 6 }}>
                {['all','entrada','saida'].map(f => (
                  <button key={f} onClick={() => setFilter(f)}
                    style={{ padding: '6px 14px', borderRadius: 100, border: '1px solid var(--border)', background: filter === f ? 'var(--red)' : 'transparent', color: filter === f ? '#fff' : 'var(--text2)', fontFamily: 'DM Sans, sans-serif', fontSize: '.75rem', fontWeight: 600, cursor: 'pointer' }}>
                    {f === 'all' ? 'Todas' : f === 'entrada' ? 'Entradas' : 'Saídas'}
                  </button>
                ))}
              </div>
            </div>
            {loading ? [1,2,3].map(i => <div key={i} className="skel" style={{ height: 52, marginBottom: 8 }} />) :
              visible.length === 0 ? <div style={{ color: 'var(--text3)', textAlign: 'center', padding: 28, fontSize: '.85rem' }}>Nenhuma movimentação.</div> :
              visible.map(m => {
                const d = new Date(m.data + 'T12:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })
                return (
                  <div key={m.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '13px 16px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, marginBottom: 8 }}>
                    <div style={{ width: 8, height: 8, borderRadius: '50%', flexShrink: 0, background: m.tipo === 'entrada' ? 'var(--green)' : 'var(--red)' }} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: '.855rem', fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{catIcon[m.categoria] || '📌'} {m.descricao}</div>
                      <div style={{ fontSize: '.72rem', color: 'var(--text3)', marginTop: 1 }}>{d}{m.projeto_ref ? ' · ' + m.projeto_ref : ''}</div>
                    </div>
                    <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '.95rem', fontWeight: 700, flexShrink: 0, color: m.tipo === 'entrada' ? 'var(--green)' : 'var(--red)' }}>
                      {m.tipo === 'saida' ? '-' : '+'}{fmtFull(m.valor)}
                    </div>
                  </div>
                )
              })
            }
          </div>

          {/* Goals */}
          <div>
            <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '.95rem', fontWeight: 700, marginBottom: 14 }}>🎯 Metas por projeto</div>
            {loading ? [1,2,3].map(i => <div key={i} className="skel" style={{ height: 70, marginBottom: 8 }} />) :
              metas.length === 0 ? <div style={{ color: 'var(--text3)', fontSize: '.85rem', textAlign: 'center', padding: 20 }}>Nenhuma meta cadastrada.</div> :
              metas.map(m => {
                const slug = m.nome.toLowerCase().replace(/[^a-z0-9]/gi, '')
                const arrecadado = movs.filter(f => f.tipo === 'entrada' && f.projeto_ref && f.projeto_ref.toLowerCase().replace(/[^a-z0-9]/gi, '').includes(slug.slice(0, 6))).reduce((a, f) => a + Number(f.valor), 0)
                const pct = Math.min(100, Math.round((arrecadado / Number(m.meta)) * 100))
                return (
                  <div key={m.id} style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10, padding: '14px 16px', marginBottom: 8 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 7 }}>
                      <span style={{ fontSize: '.855rem', fontWeight: 600 }}>{m.nome}</span>
                      <span style={{ fontSize: '.72rem', fontWeight: 700, color: 'var(--red)' }}>{pct}%</span>
                    </div>
                    <div style={{ height: 5, background: 'var(--bg3)', borderRadius: 100, overflow: 'hidden' }}>
                      <div className="fin-goal-fill" style={{ width: `${pct}%` }} />
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '.68rem', color: 'var(--text3)', marginTop: 5 }}>
                      <span>{fmtBRL(arrecadado)} arrecadado</span>
                      <span>meta: {fmtBRL(Number(m.meta))}</span>
                    </div>
                  </div>
                )
              })
            }
          </div>
        </div>
      </div>
      <style>{`
        @media(max-width:900px){ .fin-totals-grid{grid-template-columns:repeat(2,1fr)!important;} .fin-body-grid{grid-template-columns:1fr!important;} }
        @media(max-width:480px){ .fin-totals-grid{grid-template-columns:repeat(2,1fr)!important;} }
      `}</style>
    </div>
  )
}
