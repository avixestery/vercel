'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

interface HeroProps {
  onOpenTab: (tab: string) => void
}

export default function Hero({ onOpenTab }: HeroProps) {
  const [stats, setStats] = useState({ ideias: '—', projetos: '—', votos: '—' })

  useEffect(() => {
    async function load() {
      const [{ count: ci }, { data: proj }, { data: opcoes }] = await Promise.all([
        supabase.from('ideias').select('*', { count: 'exact', head: true }),
        supabase.from('projetos').select('status').neq('status', 'concluido'),
        supabase.from('enquete_opcoes').select('votos'),
      ])
      setStats({
        ideias: String(ci ?? 0),
        projetos: String(proj?.length ?? 0),
        votos: String(opcoes?.reduce((a, o) => a + o.votos, 0) ?? 0),
      })
    }
    load()
  }, [])

  return (
    <section id="home" style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      textAlign: 'center', padding: '100px 20px 72px', position: 'relative', overflow: 'hidden'
    }}>
      {/* bg glow */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse 70% 50% at 50% 0%,rgba(232,25,44,.16) 0%,transparent 60%)',
        pointerEvents: 'none'
      }} />
      {/* grid */}
      <div className="hero-grid" />
      {/* red top line */}
      <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 3, background: 'linear-gradient(90deg,transparent,var(--red),transparent)' }} />

      <div style={{ position: 'relative', zIndex: 1, width: '100%', maxWidth: 860, margin: '0 auto' }}>
        <div style={{
          display: 'inline-flex', alignItems: 'center', gap: 8,
          background: 'var(--red-subtle)', border: '1px solid rgba(232,25,44,.3)',
          color: 'var(--red-light)', fontSize: '.75rem', fontWeight: 700,
          padding: '5px 14px', borderRadius: 100, letterSpacing: '.06em',
          textTransform: 'uppercase', marginBottom: 24
        }}>
          <span className="pulse-dot" />
          Grêmio Estudantil ativo — Ideal Batista Campos
        </div>

        <h1 style={{
          fontFamily: 'Syne, sans-serif',
          fontSize: 'clamp(3rem,8vw,7rem)',
          fontWeight: 800, lineHeight: .95,
          letterSpacing: '-.03em', marginBottom: 16
        }}>
          Representa<span style={{ color: 'var(--red)' }}>+</span>
        </h1>

        <p style={{ fontSize: 'clamp(1rem,2.2vw,1.25rem)', color: 'var(--text2)', maxWidth: 500, margin: '0 auto 10px', fontWeight: 300 }}>
          O grêmio que representa você. Sua voz importa — fale e a gente escuta.
        </p>
        <p style={{ fontSize: '.8rem', color: 'var(--text3)', marginBottom: 40, letterSpacing: '.03em' }}>
          🏫 Colégio Ideal Batista Campos · Belém, Pará
        </p>

        <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap', marginBottom: 56 }}>
          <a href="#ideias" style={btnStyle('primary')}>💡 Enviar ideia</a>
          <a href="#ideias" onClick={() => onOpenTab('denuncia')} style={btnStyle('secondary')}>🕵️ Denúncia anônima</a>
          <a href="#anuncios" style={btnStyle('ghost')}>📢 Ver anúncios</a>
        </div>

        <div style={{ display: 'flex', gap: 40, justifyContent: 'center', flexWrap: 'wrap' }}>
          {[
            { num: stats.ideias, label: 'Ideias recebidas' },
            { num: stats.projetos, label: 'Projetos ativos' },
            { num: stats.votos, label: 'Votos nas enquetes' },
            { num: '100%', label: 'Anonimato garantido' },
          ].map(s => (
            <div key={s.label} style={{ textAlign: 'center' }}>
              <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.9rem', fontWeight: 800, color: 'var(--red)' }}>{s.num}</div>
              <div style={{ fontSize: '.75rem', color: 'var(--text3)', marginTop: 1, fontWeight: 500 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

function btnStyle(variant: 'primary' | 'secondary' | 'ghost'): React.CSSProperties {
  const base: React.CSSProperties = {
    display: 'inline-flex', alignItems: 'center', gap: 7,
    padding: '12px 22px', borderRadius: 10,
    fontFamily: 'DM Sans, sans-serif', fontSize: '.9rem', fontWeight: 600,
    cursor: 'pointer', textDecoration: 'none', transition: 'var(--t)',
    border: 'none',
  }
  if (variant === 'primary') return { ...base, background: 'var(--red)', color: '#fff' }
  if (variant === 'secondary') return { ...base, background: 'var(--surface)', color: 'var(--text)', border: '1px solid var(--border)' }
  return { ...base, background: 'transparent', color: 'var(--text2)', border: '1px solid var(--border)' }
}
