'use client'
import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'

type Evento = { id: string; titulo: string; descricao: string | null; data: string; tipo: string }
type EvDay = { y: number; m: number; d: number }

const MN = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro']
const DN = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb']
const tipoIcon: Record<string, string> = { evento:'🎉', prova:'📝', reuniao:'🤝', outro:'📌' }

export default function CalendarioSection() {
  const [eventos, setEventos] = useState<Evento[]>([])
  const [evDays, setEvDays] = useState<EvDay[]>([])
  const [cY, setCY] = useState(new Date().getFullYear())
  const [cM, setCM] = useState(new Date().getMonth())
  const today = new Date()

  useEffect(() => {
    supabase.from('eventos').select('*').eq('publicado', true).order('data').then(({ data }) => {
      setEventos(data || [])
      setEvDays((data || []).map(e => { const d = new Date(e.data + 'T12:00:00'); return { y: d.getFullYear(), m: d.getMonth(), d: d.getDate() } }))
    })
  }, [])

  function changeMonth(dir: number) {
    let nm = cM + dir, ny = cY
    if (nm < 0) { nm = 11; ny-- }
    if (nm > 11) { nm = 0; ny++ }
    setCM(nm); setCY(ny)
  }

  const fd = new Date(cY, cM, 1).getDay()
  const dim = new Date(cY, cM + 1, 0).getDate()

  return (
    <div style={{ borderTop: '1px solid var(--border)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }} id="calendario">
        <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Organização</div>
        <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>Calendário escolar</h2>
        <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7, marginBottom: 28 }}>Provas, eventos e reuniões num só lugar.</p>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 350px', gap: 40, alignItems: 'start' }} className="cal-outer-grid">
          {/* Event list */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 9 }}>
            {eventos.length === 0 ? (
              [1,2,3].map(i => <div key={i} className="skel" style={{ height: 60, borderRadius: 10 }} />)
            ) : eventos.map(e => {
              const d = new Date(e.data + 'T12:00:00')
              return (
                <div key={e.id} style={{ display: 'flex', gap: 12, alignItems: 'flex-start', padding: 12, background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 10 }}>
                  <div style={{ minWidth: 38, textAlign: 'center', background: 'var(--bg3)', borderRadius: 8, padding: '6px 4px', flexShrink: 0 }}>
                    <div style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.15rem', fontWeight: 800, lineHeight: 1, color: 'var(--red)' }}>{d.getDate()}</div>
                    <div style={{ fontSize: '.6rem', fontWeight: 700, textTransform: 'uppercase', color: 'var(--text3)', marginTop: 2 }}>{MN[d.getMonth()].slice(0, 3)}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: '.855rem', fontWeight: 600, marginBottom: 2 }}>{tipoIcon[e.tipo] || '📌'} {e.titulo}</div>
                    {e.descricao && <div style={{ fontSize: '.72rem', color: 'var(--text3)' }}>{e.descricao}</div>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Calendar widget */}
          <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 16, padding: 22 }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 18 }}>
              <button onClick={() => changeMonth(-1)} style={{ width: 32, height: 32, border: '1px solid var(--border)', borderRadius: 7, background: 'transparent', color: 'var(--text2)', cursor: 'pointer', fontSize: '.9rem' }}>←</button>
              <span style={{ fontFamily: 'Syne, sans-serif', fontSize: '1rem', fontWeight: 700 }}>{MN[cM]} {cY}</span>
              <button onClick={() => changeMonth(1)} style={{ width: 32, height: 32, border: '1px solid var(--border)', borderRadius: 7, background: 'transparent', color: 'var(--text2)', cursor: 'pointer', fontSize: '.9rem' }}>→</button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 2 }}>
              {DN.map(d => <div key={d} style={{ textAlign: 'center', fontSize: '.62rem', fontWeight: 700, color: 'var(--text3)', textTransform: 'uppercase', padding: '7px 0' }}>{d}</div>)}
              {Array.from({ length: fd }, (_, i) => <div key={`e${i}`} />)}
              {Array.from({ length: dim }, (_, i) => {
                const day = i + 1
                const isToday = today.getFullYear() === cY && today.getMonth() === cM && today.getDate() === day
                const hasEv = evDays.some(e => e.y === cY && e.m === cM && e.d === day)
                return (
                  <div key={day} className={`cal-d${isToday ? ' today' : ''}${hasEv ? ' has-ev' : ''}`}>
                    {day}
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </div>
      <style>{`@media(max-width:900px){.cal-outer-grid{grid-template-columns:1fr!important;}}`}</style>
    </div>
  )
}
