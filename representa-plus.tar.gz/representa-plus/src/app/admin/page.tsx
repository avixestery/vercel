'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'

type Page = 'dashboard'|'ideias'|'denuncias'|'contatos'|'anuncios'|'projetos'|'financeiro'|'enquetes'|'eventos'
type BtnV = 'primary'|'secondary'|'danger'|'success'

function fmtDate(d:string){return d?new Date(d).toLocaleString('pt-BR'):'—'}
function fmtBRL(v:number){return 'R$ '+Number(v).toLocaleString('pt-BR',{minimumFractionDigits:2})}

function btnSt(v:BtnV):React.CSSProperties{
  const b:React.CSSProperties={padding:'6px 14px',borderRadius:8,fontFamily:'DM Sans,sans-serif',fontSize:'.78rem',fontWeight:600,cursor:'pointer',border:'none',flexShrink:0}
  if(v==='primary')return{...b,background:'var(--red)',color:'#fff'}
  if(v==='secondary')return{...b,background:'var(--surface2)',color:'var(--text)',border:'1px solid var(--border)'}
  if(v==='danger')return{...b,background:'rgba(232,25,44,.15)',color:'var(--red-light)',border:'1px solid rgba(232,25,44,.25)'}
  return{...b,background:'rgba(34,197,94,.12)',color:'#22c55e',border:'1px solid rgba(34,197,94,.25)'}
}

const inp:React.CSSProperties={width:'100%',background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:9,padding:'11px 14px',color:'var(--text)',fontFamily:'DM Sans,sans-serif',fontSize:'.9rem',outline:'none'}

function Tag({status}:{status:string}){
  const c:Record<string,[string,string]>={pendente:['rgba(245,166,35,.12)','var(--gold)'],em_analise:['rgba(59,130,246,.12)','#3b82f6'],respondida:['rgba(34,197,94,.12)','#22c55e'],resolvida:['rgba(34,197,94,.12)','#22c55e'],arquivada:['rgba(255,255,255,.06)','var(--text3)']}
  const[bg,col]=c[status]||c.pendente
  return <span style={{display:'inline-block',fontSize:'.65rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'.06em',padding:'2px 8px',borderRadius:4,background:bg,color:col}}>{status.replace('_',' ')}</span>
}

function Field({label,children}:{label:string,children:React.ReactNode}){
  return <div style={{marginBottom:16}}><label style={{display:'block',fontSize:'.78rem',fontWeight:600,color:'var(--text2)',marginBottom:6}}>{label}</label>{children}</div>
}

function Row({children}:{children:React.ReactNode}){
  return <div style={{padding:'16px 20px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'flex-start',gap:12}}>{children}</div>
}

export default function AdminPage(){
  const [user,setUser]=useState<{email:string}|null>(null)
  const [page,setPage]=useState<Page>('dashboard')
  const [sidebarOpen,setSidebarOpen]=useState(false)
  const [modal,setModal]=useState<{title:string,body:React.ReactNode,foot:React.ReactNode}|null>(null)
  const [loginEmail,setLoginEmail]=useState('')
  const [loginPass,setLoginPass]=useState('')
  const [loginErr,setLoginErr]=useState('')
  const [loginLoading,setLoginLoading]=useState(false)
  const [toast,setToast]=useState<{icon:string,text:string}|null>(null)
  // data
  const [ideias,setIdeias]=useState<any[]>([])
  const [denuncias,setDenuncias]=useState<any[]>([])
  const [contatos,setContatos]=useState<any[]>([])
  const [anuncios,setAnuncios]=useState<any[]>([])
  const [projetos,setProjetos]=useState<any[]>([])
  const [enquetes,setEnquetes]=useState<any[]>([])
  const [eventos,setEventos]=useState<any[]>([])
  const [finMovs,setFinMovs]=useState<any[]>([])
  const [finMetas,setFinMetas]=useState<any[]>([])
  const [badges,setBadges]=useState({ideias:0,denuncias:0,contatos:0})
  const [filtroI,setFiltroI]=useState('')
  const [filtroD,setFiltroD]=useState('')

  function showToast(icon:string,text:string){setToast({icon,text});setTimeout(()=>setToast(null),3200)}
  function openModal(m:typeof modal){setModal(m)}
  function closeModal(){setModal(null)}

  useEffect(()=>{supabase.auth.getSession().then(({data:{session}})=>{if(session?.user)setUser({email:session.user.email!})})},[])
  useEffect(()=>{if(!user)return;const loaders:any={dashboard:loadDashboard,ideias:loadIdeias,denuncias:loadDenuncias,contatos:loadContatos,anuncios:loadAnuncios,projetos:loadProjetos,financeiro:loadFin,enquetes:loadEnquetes,eventos:loadEventos};loaders[page]?.()},[page,user,filtroI,filtroD])

  async function doLogin(){
    if(!loginEmail||!loginPass){setLoginErr('Preencha e-mail e senha.');return}
    setLoginLoading(true);setLoginErr('')
    const{data,error}=await supabase.auth.signInWithPassword({email:loginEmail,password:loginPass})
    setLoginLoading(false)
    if(error){setLoginErr('E-mail ou senha incorretos.');return}
    setUser({email:data.user.email!})
  }
  async function doLogout(){await supabase.auth.signOut();setUser(null)}

  async function loadDashboard(){
    const[{count:ci},{count:cd},{count:cc}]=await Promise.all([
      supabase.from('ideias').select('*',{count:'exact',head:true}).eq('status','pendente'),
      supabase.from('denuncias').select('*',{count:'exact',head:true}).eq('status','pendente'),
      supabase.from('contatos').select('*',{count:'exact',head:true}).eq('respondido',false),
    ])
    setBadges({ideias:ci??0,denuncias:cd??0,contatos:cc??0})
    loadIdeias()
  }
  async function loadIdeias(){let q=supabase.from('ideias').select('*').order('created_at',{ascending:false});if(filtroI)q=q.eq('status',filtroI);const{data}=await q;setIdeias(data||[])}
  async function loadDenuncias(){let q=supabase.from('denuncias').select('*').order('created_at',{ascending:false});if(filtroD)q=q.eq('status',filtroD);const{data}=await q;setDenuncias(data||[])}
  async function loadContatos(){const{data}=await supabase.from('contatos').select('*').order('created_at',{ascending:false});setContatos(data||[])}
  async function loadAnuncios(){const{data}=await supabase.from('anuncios').select('*').order('created_at',{ascending:false});setAnuncios(data||[])}
  async function loadProjetos(){const{data}=await supabase.from('projetos').select('*').order('ordem');setProjetos(data||[])}
  async function loadFin(){const[{data:m},{data:mt}]=await Promise.all([supabase.from('financeiro').select('*').order('data',{ascending:false}),supabase.from('metas_financeiras').select('*').order('created_at',{ascending:false})]);setFinMovs(m||[]);setFinMetas(mt||[])}
  async function loadEnquetes(){const{data}=await supabase.from('enquetes').select('*,enquete_opcoes(*)').order('created_at',{ascending:false});setEnquetes(data||[])}
  async function loadEventos(){const{data}=await supabase.from('eventos').select('*').order('data');setEventos(data||[])}

  async function delItem(table:string,id:string,reload:()=>void){
    if(!confirm('Excluir?'))return
    await supabase.from(table).delete().eq('id',id)
    showToast('🗑️','Excluído.');closeModal();reload()
  }

  // Modals
  function openIdeiaModal(item:any){
    let status=item.status,resposta=item.resposta||''
    openModal({title:'💡 Gerenciar Ideia',body:(<div>
      <div style={{background:'var(--bg3)',borderRadius:8,padding:14,fontSize:'.875rem',color:'var(--text2)',marginBottom:16}}>{item.texto}</div>
      <Field label="Status"><select defaultValue={item.status} onChange={e=>status=e.target.value} style={{...inp,appearance:'none'}}>{['pendente','em_analise','respondida','arquivada'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select></Field>
      <Field label="Resposta"><textarea defaultValue={item.resposta||''} onChange={e=>resposta=e.target.value} style={{...inp,minHeight:80,resize:'vertical'}} placeholder="Resposta..."/></Field>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      <button onClick={()=>delItem('ideias',item.id,loadIdeias)} style={btnSt('danger')}>🗑</button>
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{await supabase.from('ideias').update({status,resposta}).eq('id',item.id);showToast('✅','Atualizado!');closeModal();loadIdeias()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openDenModal(item:any){
    let status=item.status,nota=item.nota_interna||''
    openModal({title:'🔒 Gerenciar Denúncia',body:(<div>
      <div style={{background:'var(--bg3)',borderRadius:8,padding:14,fontSize:'.875rem',color:'var(--text2)',marginBottom:16}}>{item.texto}</div>
      <Field label="Status"><select defaultValue={item.status} onChange={e=>status=e.target.value} style={{...inp,appearance:'none'}}>{['pendente','em_analise','resolvida','arquivada'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}</select></Field>
      <Field label="Nota interna"><textarea defaultValue={item.nota_interna||''} onChange={e=>nota=e.target.value} style={{...inp,minHeight:80,resize:'vertical'}} placeholder="Notas..."/></Field>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      <button onClick={()=>delItem('denuncias',item.id,loadDenuncias)} style={btnSt('danger')}>🗑</button>
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{await supabase.from('denuncias').update({status,nota_interna:nota}).eq('id',item.id);showToast('✅','Atualizado!');closeModal();loadDenuncias()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openAnuncioModal(item?:any){
    let titulo=item?.titulo||'',descricao=item?.descricao||'',categoria=item?.categoria||'evento',destaque=item?.destaque??false,publicado=item?.publicado??true
    openModal({title:item?'✏️ Editar Anúncio':'📢 Novo Anúncio',body:(<div>
      <Field label="Título"><input defaultValue={titulo} onChange={e=>titulo=e.target.value} style={inp} placeholder="Título"/></Field>
      <Field label="Descrição"><textarea defaultValue={descricao} onChange={e=>descricao=e.target.value} style={{...inp,minHeight:90,resize:'vertical'}}/></Field>
      <Field label="Categoria"><select defaultValue={categoria} onChange={e=>categoria=e.target.value} style={{...inp,appearance:'none'}}>{['evento','aviso','campanha','urgente'].map(c=><option key={c} value={c}>{c}</option>)}</select></Field>
      <div style={{display:'flex',gap:20}}>
        <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.85rem',cursor:'pointer'}}><input type="checkbox" defaultChecked={destaque} onChange={e=>destaque=e.target.checked}/> Destaque</label>
        <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.85rem',cursor:'pointer'}}><input type="checkbox" defaultChecked={publicado} onChange={e=>publicado=e.target.checked}/> Publicado</label>
      </div>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      {item&&<button onClick={()=>delItem('anuncios',item.id,loadAnuncios)} style={btnSt('danger')}>🗑</button>}
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{const p={titulo,descricao,categoria,destaque,publicado};if(item)await supabase.from('anuncios').update(p).eq('id',item.id);else await supabase.from('anuncios').insert(p);showToast('✅',item?'Atualizado!':'Criado!');closeModal();loadAnuncios()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openProjetoModal(item?:any){
    let nome=item?.nome||'',descricao=item?.descricao||'',status=item?.status||'planejamento',progresso=item?.progresso??0,voluntarios=item?.voluntarios??0,maxP=item?.max_participantes??0,semP=item?.sem_participantes??false
    openModal({title:item?'✏️ Editar Projeto':'🚀 Novo Projeto',body:(<div>
      <Field label="Nome"><input defaultValue={nome} onChange={e=>nome=e.target.value} style={inp} placeholder="Nome do projeto"/></Field>
      <Field label="Descrição"><textarea defaultValue={descricao} onChange={e=>descricao=e.target.value} style={{...inp,minHeight:80,resize:'vertical'}}/></Field>
      <Field label="Status"><select defaultValue={status} onChange={e=>status=e.target.value} style={{...inp,appearance:'none'}}>{['planejamento','andamento','concluido'].map(s=><option key={s} value={s}>{s}</option>)}</select></Field>
      <Field label="Progresso (%)"><input type="number" defaultValue={progresso} onChange={e=>progresso=+e.target.value} style={inp} min={0} max={100}/></Field>
      <div style={{background:'var(--bg3)',border:'1px solid var(--border)',borderRadius:10,padding:16,marginBottom:16}}>
        <div style={{fontSize:'.75rem',fontWeight:700,color:'var(--text2)',textTransform:'uppercase',letterSpacing:'.08em',marginBottom:12}}>👥 Participantes e Voluntários</div>
        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12,marginBottom:12}}>
          <Field label="Voluntários necessários"><input type="number" defaultValue={voluntarios} onChange={e=>voluntarios=+e.target.value} style={inp} min={0}/></Field>
          <Field label="Participantes máximo"><input type="number" defaultValue={maxP} onChange={e=>maxP=+e.target.value} style={inp} min={0}/></Field>
        </div>
        <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.855rem',cursor:'pointer'}}>
          <input type="checkbox" defaultChecked={semP} onChange={e=>semP=e.target.checked}/>
          Nenhum participante e voluntário <span style={{fontSize:'.72rem',color:'var(--text3)',marginLeft:4}}>(oculta no site)</span>
        </label>
      </div>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      {item&&<button onClick={()=>delItem('projetos',item.id,loadProjetos)} style={btnSt('danger')}>🗑</button>}
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{const p={nome,descricao,status,progresso,voluntarios:semP?0:voluntarios,max_participantes:semP?0:maxP,sem_participantes:semP};if(item)await supabase.from('projetos').update(p).eq('id',item.id);else await supabase.from('projetos').insert(p);showToast('✅',item?'Atualizado!':'Criado!');closeModal();loadProjetos()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openMovModal(tipo:string,item?:any){
    const isEnt=(item?.tipo||tipo)==='entrada'
    let descricao=item?.descricao||'',valor=item?.valor||'',data=item?.data||new Date().toISOString().split('T')[0],categoria=item?.categoria||(isEnt?'arrecadacao':'material'),projeto_ref=item?.projeto_ref||'',publicado=item?.publicado??true
    openModal({title:item?`✏️ Editar ${isEnt?'Entrada':'Saída'}`:isEnt?'+ Nova Entrada':'- Nova Saída',body:(<div>
      <div style={{display:'inline-flex',alignItems:'center',gap:8,padding:'5px 14px',borderRadius:100,marginBottom:16,fontSize:'.82rem',fontWeight:700,background:isEnt?'rgba(34,197,94,.12)':'rgba(232,25,44,.12)',color:isEnt?'#22c55e':'var(--red-light)'}}>{isEnt?'↑ ENTRADA':'↓ SAÍDA'}</div>
      <Field label="Descrição"><input defaultValue={descricao} onChange={e=>descricao=e.target.value} style={inp} placeholder="Ex: Arrecadação rifas..."/></Field>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Field label="Valor (R$)"><input type="number" defaultValue={valor} onChange={e=>valor=e.target.value} style={inp} min={0.01} step={0.01}/></Field>
        <Field label="Data"><input type="date" defaultValue={data} onChange={e=>data=e.target.value} style={inp}/></Field>
      </div>
      <Field label="Categoria"><select defaultValue={categoria} onChange={e=>categoria=e.target.value} style={{...inp,appearance:'none'}}>{(isEnt?['arrecadacao','doacao','evento','outros']:['material','servico','projeto','outros']).map(c=><option key={c} value={c}>{c}</option>)}</select></Field>
      <Field label="Projeto relacionado (opcional)"><input defaultValue={projeto_ref} onChange={e=>projeto_ref=e.target.value} style={inp} placeholder="Ex: Escola Mais Verde"/></Field>
      <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.855rem',cursor:'pointer'}}><input type="checkbox" defaultChecked={publicado} onChange={e=>publicado=e.target.checked}/> Visível no site público</label>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      {item&&<button onClick={()=>delItem('financeiro',item.id,loadFin)} style={btnSt('danger')}>🗑</button>}
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{const v=parseFloat(String(valor));if(!descricao.trim()){showToast('⚠️','Informe a descrição.');return}if(!v||v<=0){showToast('⚠️','Valor inválido.');return}const p={tipo:item?.tipo||tipo,descricao,valor:v,data,categoria,projeto_ref:projeto_ref||null,publicado};if(item)await supabase.from('financeiro').update(p).eq('id',item.id);else await supabase.from('financeiro').insert(p);showToast('✅',item?'Atualizado!':'Registrado!');closeModal();loadFin()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openMetaModal(item?:any){
    let nome=item?.nome||'',meta=item?.meta||'',descricao=item?.descricao||'',ativa=item?.ativa??true
    openModal({title:item?'✏️ Editar Meta':'🎯 Nova Meta',body:(<div>
      <Field label="Nome do projeto"><input defaultValue={nome} onChange={e=>nome=e.target.value} style={inp} placeholder="Ex: Escola Mais Verde"/></Field>
      <Field label="Valor da meta (R$)"><input type="number" defaultValue={meta} onChange={e=>meta=e.target.value} style={inp} min={1} step={0.01}/></Field>
      <Field label="Descrição (opcional)"><input defaultValue={descricao} onChange={e=>descricao=e.target.value} style={inp} placeholder="Breve descrição"/></Field>
      <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.855rem',cursor:'pointer'}}><input type="checkbox" defaultChecked={ativa} onChange={e=>ativa=e.target.checked}/> Exibir no site</label>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      {item&&<button onClick={()=>delItem('metas_financeiras',item.id,loadFin)} style={btnSt('danger')}>🗑</button>}
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{if(!nome.trim()){showToast('⚠️','Informe o nome.');return}const p={nome,meta:parseFloat(String(meta)),descricao:descricao||null,ativa};if(item)await supabase.from('metas_financeiras').update(p).eq('id',item.id);else await supabase.from('metas_financeiras').insert(p);showToast('✅',item?'Atualizada!':'Criada!');closeModal();loadFin()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  function openEnqueteModal(){
    let pergunta='',opcoesText='',encerra=''
    openModal({title:'🗳️ Nova Enquete',body:(<div>
      <Field label="Pergunta"><input onChange={e=>pergunta=e.target.value} style={inp} placeholder="Qual a sua pergunta?"/></Field>
      <Field label="Opções (uma por linha)"><textarea onChange={e=>opcoesText=e.target.value} style={{...inp,minHeight:120,resize:'vertical'}} placeholder={'🎵 Festival de música\n🍕 Festa junina'}/></Field>
      <Field label="Encerra em (opcional)"><input type="datetime-local" onChange={e=>encerra=e.target.value} style={inp}/></Field>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{const opts=opcoesText.trim().split('\n').filter(o=>o.trim());if(!pergunta){showToast('⚠️','Escreva a pergunta.');return}if(opts.length<2){showToast('⚠️','Mín. 2 opções.');return}const{data:enq}=await supabase.from('enquetes').insert({pergunta,encerra_em:encerra||null}).select().single();if(!enq){showToast('❌','Erro.');return}await supabase.from('enquete_opcoes').insert(opts.map((texto,i)=>({enquete_id:enq.id,texto:texto.trim(),votos:0,ordem:i+1})));showToast('✅','Enquete criada!');closeModal();loadEnquetes()}} style={btnSt('primary')}>Criar →</button>
    </div>)})
  }

  function openEventoModal(item?:any){
    let titulo=item?.titulo||'',descricao=item?.descricao||'',data=item?.data||'',tipo=item?.tipo||'evento',publicado=item?.publicado??true
    openModal({title:item?'✏️ Editar Evento':'📅 Novo Evento',body:(<div>
      <Field label="Título"><input defaultValue={titulo} onChange={e=>titulo=e.target.value} style={inp} placeholder="Título do evento"/></Field>
      <Field label="Descrição (opcional)"><input defaultValue={descricao} onChange={e=>descricao=e.target.value} style={inp} placeholder="Breve descrição"/></Field>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:12}}>
        <Field label="Data"><input type="date" defaultValue={data} onChange={e=>data=e.target.value} style={inp}/></Field>
        <Field label="Tipo"><select defaultValue={tipo} onChange={e=>tipo=e.target.value} style={{...inp,appearance:'none'}}>{['evento','prova','reuniao','outro'].map(t=><option key={t} value={t}>{t}</option>)}</select></Field>
      </div>
      <label style={{display:'flex',alignItems:'center',gap:8,fontSize:'.855rem',cursor:'pointer'}}><input type="checkbox" defaultChecked={publicado} onChange={e=>publicado=e.target.checked}/> Publicado no calendário</label>
    </div>),foot:(<div style={{display:'flex',gap:8,justifyContent:'flex-end'}}>
      {item&&<button onClick={()=>delItem('eventos',item.id,loadEventos)} style={btnSt('danger')}>🗑</button>}
      <button onClick={closeModal} style={btnSt('secondary')}>Cancelar</button>
      <button onClick={async()=>{if(!titulo||!data){showToast('⚠️','Preencha título e data.');return}const p={titulo,descricao:descricao||null,data,tipo,publicado};if(item)await supabase.from('eventos').update(p).eq('id',item.id);else await supabase.from('eventos').insert(p);showToast('✅',item?'Atualizado!':'Criado!');closeModal();loadEventos()}} style={btnSt('primary')}>Salvar →</button>
    </div>)})
  }

  const finEnt=finMovs.filter(m=>m.tipo==='entrada').reduce((a:number,m:any)=>a+Number(m.valor),0)
  const finSai=finMovs.filter(m=>m.tipo==='saida').reduce((a:number,m:any)=>a+Number(m.valor),0)
  const finMetaTotal=finMetas.reduce((a:number,m:any)=>a+Number(m.meta),0)

  const navItems=[
    {id:'dashboard' as Page,icon:'📊',label:'Dashboard'},
    {id:'ideias' as Page,icon:'💡',label:'Ideias'},
    {id:'denuncias' as Page,icon:'🔒',label:'Ouvidoria'},
    {id:'contatos' as Page,icon:'📩',label:'Contatos'},
    {id:'anuncios' as Page,icon:'📢',label:'Anúncios'},
    {id:'projetos' as Page,icon:'🚀',label:'Projetos'},
    {id:'financeiro' as Page,icon:'💰',label:'Financeiro'},
    {id:'enquetes' as Page,icon:'🗳️',label:'Enquetes'},
    {id:'eventos' as Page,icon:'📅',label:'Eventos'},
  ]

  if(!user)return(
    <div style={{minHeight:'100vh',display:'flex',alignItems:'center',justifyContent:'center',padding:24,background:'radial-gradient(ellipse 60% 50% at 50% 0%,rgba(232,25,44,.12) 0%,transparent 60%)'}}>
      <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:20,padding:'48px 40px',width:'100%',maxWidth:400,textAlign:'center'}}>
        <div style={{fontFamily:'Syne,sans-serif',fontSize:'2rem',fontWeight:800,marginBottom:4}}>Representa<span style={{color:'var(--red)'}}>+</span></div>
        <div style={{fontSize:'.82rem',color:'var(--text3)',marginBottom:36}}>Área Administrativa</div>
        <div style={{fontSize:'2.2rem',marginBottom:20}}>🔐</div>
        <h2 style={{fontFamily:'Syne,sans-serif',fontSize:'1.3rem',fontWeight:700,marginBottom:6}}>Entrar</h2>
        <p style={{fontSize:'.85rem',color:'var(--text2)',marginBottom:28}}>Acesso restrito aos membros do grêmio.</p>
        <input type="email" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doLogin()} style={{...inp,marginBottom:12}} placeholder="E-mail institucional"/>
        <input type="password" value={loginPass} onChange={e=>setLoginPass(e.target.value)} onKeyDown={e=>e.key==='Enter'&&doLogin()} style={{...inp,marginBottom:12}} placeholder="Senha"/>
        <button onClick={doLogin} disabled={loginLoading} style={{width:'100%',padding:13,background:'var(--red)',color:'#fff',border:'none',borderRadius:10,fontFamily:'Syne,sans-serif',fontSize:'.95rem',fontWeight:700,cursor:loginLoading?'not-allowed':'pointer',opacity:loginLoading?.5:1}}>
          {loginLoading?'Entrando...':'Entrar →'}
        </button>
        {loginErr&&<div style={{fontSize:'.78rem',color:'var(--red-light)',marginTop:10}}>{loginErr}</div>}
      </div>
    </div>
  )

  return(
    <div style={{display:'flex',minHeight:'100vh'}}>
      {/* Sidebar */}
      <aside className={sidebarOpen?'sidebar open':'sidebar'} style={{width:240,background:'var(--bg2)',borderRight:'1px solid var(--border)',display:'flex',flexDirection:'column',position:'fixed',top:0,bottom:0,left:0,zIndex:100}}>
        <div style={{padding:'24px 20px 20px',borderBottom:'1px solid var(--border)'}}>
          <div style={{fontFamily:'Syne,sans-serif',fontSize:'1.2rem',fontWeight:800}}>Representa<span style={{color:'var(--red)'}}>+</span></div>
          <div style={{fontSize:'.7rem',color:'var(--text3)',marginTop:2}}>Painel Administrativo</div>
        </div>
        <nav style={{flex:1,padding:'16px 12px',display:'flex',flexDirection:'column',gap:3,overflowY:'auto'}}>
          {navItems.map(n=>(
            <button key={n.id} onClick={()=>{setPage(n.id);setSidebarOpen(false)}}
              style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',borderRadius:9,cursor:'pointer',border:page===n.id?'1px solid rgba(232,25,44,.2)':'1px solid transparent',background:page===n.id?'var(--red-subtle)':'transparent',color:page===n.id?'var(--red-light)':'var(--text2)',fontFamily:'DM Sans,sans-serif',fontSize:'.875rem',fontWeight:500,width:'100%',textAlign:'left'}}>
              <span>{n.icon}</span>{n.label}
              {n.id==='ideias'&&badges.ideias>0&&<span style={{marginLeft:'auto',background:'var(--red)',color:'#fff',fontSize:'.65rem',fontWeight:700,padding:'2px 6px',borderRadius:100}}>{badges.ideias}</span>}
              {n.id==='denuncias'&&badges.denuncias>0&&<span style={{marginLeft:'auto',background:'var(--red)',color:'#fff',fontSize:'.65rem',fontWeight:700,padding:'2px 6px',borderRadius:100}}>{badges.denuncias}</span>}
              {n.id==='contatos'&&badges.contatos>0&&<span style={{marginLeft:'auto',background:'var(--red)',color:'#fff',fontSize:'.65rem',fontWeight:700,padding:'2px 6px',borderRadius:100}}>{badges.contatos}</span>}
            </button>
          ))}
        </nav>
        <div style={{padding:'16px 12px',borderTop:'1px solid var(--border)'}}>
          <div style={{display:'flex',alignItems:'center',gap:10,padding:'10px 12px',borderRadius:9,background:'var(--surface)',marginBottom:6}}>
            <div style={{width:32,height:32,background:'var(--red)',borderRadius:'50%',display:'grid',placeItems:'center',fontSize:'.85rem',fontWeight:700,color:'#fff',flexShrink:0}}>{user.email[0].toUpperCase()}</div>
            <div style={{fontSize:'.72rem',color:'var(--text2)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{user.email}</div>
          </div>
          <button onClick={doLogout} style={{display:'flex',alignItems:'center',gap:8,width:'100%',padding:'9px 12px',border:'none',background:'transparent',color:'var(--text3)',cursor:'pointer',borderRadius:8,fontFamily:'DM Sans,sans-serif',fontSize:'.82rem'}}>🚪 Sair da conta</button>
        </div>
      </aside>

      {/* Main */}
      <div className="admin-main" style={{marginLeft:240,flex:1,display:'flex',flexDirection:'column',minHeight:'100vh'}}>
        <div style={{height:60,background:'var(--bg2)',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between',padding:'0 28px',position:'sticky',top:0,zIndex:50}}>
          <div style={{display:'flex',alignItems:'center',gap:12}}>
            <button className="burger" onClick={()=>setSidebarOpen(!sidebarOpen)} style={{display:'none',flexDirection:'column',gap:4,cursor:'pointer',padding:8,background:'none',border:'none'}}>
              {[0,1,2].map(i=><span key={i} style={{display:'block',width:20,height:2,background:'var(--text)',borderRadius:2}}/>)}
            </button>
            <span style={{fontFamily:'Syne,sans-serif',fontSize:'1.1rem',fontWeight:700}}>{navItems.find(n=>n.id===page)?.icon} {navItems.find(n=>n.id===page)?.label}</span>
          </div>
          <Link href="/" style={{display:'flex',alignItems:'center',gap:6,color:'var(--text2)',textDecoration:'none',fontSize:'.82rem',fontWeight:500,padding:'6px 12px',borderRadius:7,border:'1px solid var(--border)'}}>← Ver site</Link>
        </div>

        <div style={{padding:28,flex:1}}>

          {/* DASHBOARD */}
          {page==='dashboard'&&(
            <div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:14,marginBottom:28}}>
                {[{icon:'💡',num:badges.ideias,label:'Ideias pendentes'},{icon:'🔒',num:badges.denuncias,label:'Denúncias'},{icon:'📩',num:badges.contatos,label:'Contatos'},{icon:'🗳️',num:'—',label:'Votos totais'}].map(s=>(
                  <div key={s.label} style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,padding:20}}>
                    <div style={{fontSize:'1.3rem',marginBottom:6}}>{s.icon}</div>
                    <div style={{fontFamily:'Syne,sans-serif',fontSize:'2rem',fontWeight:800,color:'var(--red)'}}>{s.num}</div>
                    <div style={{fontSize:'.75rem',color:'var(--text3)',fontWeight:500}}>{s.label}</div>
                  </div>
                ))}
              </div>
              <div style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700,marginBottom:14}}>💡 Ideias recentes</div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {ideias.slice(0,5).map(i=>(
                  <div key={i.id} style={{padding:'14px 18px',borderBottom:'1px solid var(--border)'}}>
                    <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}><Tag status={i.status}/><span style={{fontSize:'.72rem',color:'var(--text3)'}}>{fmtDate(i.created_at)}</span></div>
                    <div style={{fontSize:'.875rem',color:'var(--text2)'}}>{i.texto}</div>
                  </div>
                ))}
                {ideias.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma ideia ainda.</div>}
              </div>
            </div>
          )}

          {/* IDEIAS */}
          {page==='ideias'&&(
            <div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18,flexWrap:'wrap',gap:12}}>
                <h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>💡 Ideias</h3>
                <select value={filtroI} onChange={e=>setFiltroI(e.target.value)} style={{...inp,width:'auto',padding:'7px 28px 7px 10px',fontSize:'.8rem',appearance:'none'}}>
                  <option value="">Todos</option>{['pendente','em_analise','respondida','arquivada'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}
                </select>
              </div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {ideias.map(i=>(
                  <Row key={i.id}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                        <Tag status={i.status}/>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:i.anonimo?'var(--red-subtle)':'rgba(255,255,255,.06)',color:i.anonimo?'var(--red-light)':'#aaa'}}>{i.anonimo?'🕵️ Anônimo':`👤 ${i.nome||'—'}`}</span>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--surface2)',color:'var(--text2)'}}>{i.categoria}</span>
                        <span style={{fontSize:'.7rem',color:'var(--text3)',marginLeft:'auto'}}>{fmtDate(i.created_at)}</span>
                      </div>
                      <div style={{fontSize:'.875rem',color:'var(--text2)'}}>{i.texto}</div>
                      {i.resposta&&<div style={{marginTop:8,padding:10,background:'var(--bg3)',borderRadius:7,fontSize:'.8rem',color:'var(--text2)',borderLeft:'2px solid var(--red)'}}>💬 {i.resposta}</div>}
                    </div>
                    <button onClick={()=>openIdeiaModal(i)} style={btnSt('secondary')}>Gerenciar</button>
                  </Row>
                ))}
                {ideias.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma ideia.</div>}
              </div>
            </div>
          )}

          {/* DENÚNCIAS */}
          {page==='denuncias'&&(
            <div>
              <div style={{background:'var(--red-subtle)',border:'1px solid rgba(232,25,44,.2)',borderRadius:10,padding:'14px 18px',marginBottom:20,fontSize:'.82rem',color:'var(--text2)'}}>🔒 <strong>Área sigilosa.</strong> Trate com discrição.</div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18,flexWrap:'wrap',gap:12}}>
                <h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>🔒 Ouvidoria</h3>
                <select value={filtroD} onChange={e=>setFiltroD(e.target.value)} style={{...inp,width:'auto',padding:'7px 28px 7px 10px',fontSize:'.8rem',appearance:'none'}}>
                  <option value="">Todos</option>{['pendente','em_analise','resolvida','arquivada'].map(s=><option key={s} value={s}>{s.replace('_',' ')}</option>)}
                </select>
              </div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {denuncias.map(d=>(
                  <Row key={d.id}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                        <Tag status={d.status}/>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--red-subtle)',color:'var(--red-light)'}}>🔒 Anônimo</span>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--surface2)',color:'var(--text2)'}}>{d.categoria}</span>
                        <span style={{fontSize:'.7rem',color:'var(--text3)',marginLeft:'auto'}}>{fmtDate(d.created_at)}</span>
                      </div>
                      <div style={{fontSize:'.875rem',color:'var(--text2)'}}>{d.texto}</div>
                    </div>
                    <button onClick={()=>openDenModal(d)} style={btnSt('secondary')}>Gerenciar</button>
                  </Row>
                ))}
                {denuncias.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma denúncia.</div>}
              </div>
            </div>
          )}

          {/* CONTATOS */}
          {page==='contatos'&&(
            <div>
              <h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700,marginBottom:18}}>📩 Contatos</h3>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {contatos.map(c=>(
                  <Row key={c.id}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:c.respondido?'rgba(34,197,94,.12)':'rgba(245,166,35,.12)',color:c.respondido?'#22c55e':'var(--gold)'}}>{c.respondido?'✓ Respondido':'Novo'}</span>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'rgba(255,255,255,.06)',color:'#aaa'}}>👤 {c.nome}</span>
                        {c.email&&<span style={{fontSize:'.7rem',color:'var(--text3)'}}>{c.email}</span>}
                        <span style={{fontSize:'.7rem',color:'var(--text3)',marginLeft:'auto'}}>{fmtDate(c.created_at)}</span>
                      </div>
                      <div style={{fontSize:'.875rem',color:'var(--text2)'}}>{c.mensagem}</div>
                    </div>
                    <div style={{display:'flex',gap:6,flexShrink:0}}>
                      {!c.respondido&&<button onClick={async()=>{await supabase.from('contatos').update({respondido:true}).eq('id',c.id);showToast('✅','Marcado!');loadContatos()}} style={btnSt('success')}>✓</button>}
                      <button onClick={()=>delItem('contatos',c.id,loadContatos)} style={btnSt('danger')}>🗑</button>
                    </div>
                  </Row>
                ))}
                {contatos.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma mensagem.</div>}
              </div>
            </div>
          )}

          {/* ANÚNCIOS */}
          {page==='anuncios'&&(
            <div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}><h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>📢 Anúncios</h3><button onClick={()=>openAnuncioModal()} style={btnSt('primary')}>+ Novo</button></div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {anuncios.map(a=>(
                  <Row key={a.id}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:6,flexWrap:'wrap'}}>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--red-subtle)',color:'var(--red-light)'}}>{a.categoria}</span>
                        {a.destaque&&<span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'rgba(245,166,35,.12)',color:'var(--gold)'}}>⭐</span>}
                        {!a.publicado&&<span style={{fontSize:'.65rem',color:'var(--text3)'}}>🚫</span>}
                        <span style={{fontSize:'.7rem',color:'var(--text3)',marginLeft:'auto'}}>{fmtDate(a.created_at)}</span>
                      </div>
                      <div style={{fontWeight:600,fontSize:'.9rem',marginBottom:4}}>{a.titulo}</div>
                      <div style={{fontSize:'.835rem',color:'var(--text2)'}}>{a.descricao}</div>
                    </div>
                    <div style={{display:'flex',gap:6}}>
                      <button onClick={()=>openAnuncioModal(a)} style={btnSt('secondary')}>✏️</button>
                      <button onClick={()=>delItem('anuncios',a.id,loadAnuncios)} style={btnSt('danger')}>🗑</button>
                    </div>
                  </Row>
                ))}
                {anuncios.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhum anúncio.</div>}
              </div>
            </div>
          )}

          {/* PROJETOS */}
          {page==='projetos'&&(
            <div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}><h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>🚀 Projetos</h3><button onClick={()=>openProjetoModal()} style={btnSt('primary')}>+ Novo</button></div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {projetos.map(p=>(
                  <Row key={p.id}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8,flexWrap:'wrap'}}>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:p.status==='concluido'?'rgba(255,255,255,.07)':p.status==='andamento'?'var(--red-subtle)':'rgba(245,166,35,.12)',color:p.status==='concluido'?'#aaa':p.status==='andamento'?'var(--red-light)':'var(--gold)'}}>{p.status}</span>
                        {!p.sem_participantes&&p.voluntarios>0&&<span style={{fontSize:'.7rem',color:'var(--text3)'}}>👋 {p.voluntarios}v</span>}
                        {!p.sem_participantes&&p.max_participantes>0&&<span style={{fontSize:'.7rem',color:'var(--text3)'}}>🎯 máx.{p.max_participantes}</span>}
                        {p.sem_participantes&&<span style={{fontSize:'.7rem',color:'var(--text3)'}}>👥 Sem participantes</span>}
                      </div>
                      <div style={{fontWeight:600,fontSize:'.9rem',marginBottom:4}}>{p.nome}</div>
                      <div style={{fontSize:'.835rem',color:'var(--text2)',marginBottom:8}}>{p.descricao}</div>
                      <div style={{fontSize:'.72rem',color:'var(--text3)',marginBottom:4}}>Progresso: {p.progresso}%</div>
                      <div style={{height:4,background:'var(--bg3)',borderRadius:100,overflow:'hidden'}}><div style={{height:'100%',borderRadius:100,background:'var(--red)',width:`${p.progresso}%`}}/></div>
                    </div>
                    <div style={{display:'flex',gap:6}}>
                      <button onClick={()=>openProjetoModal(p)} style={btnSt('secondary')}>✏️</button>
                      <button onClick={()=>delItem('projetos',p.id,loadProjetos)} style={btnSt('danger')}>🗑</button>
                    </div>
                  </Row>
                ))}
                {projetos.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhum projeto.</div>}
              </div>
            </div>
          )}

          {/* FINANCEIRO */}
          {page==='financeiro'&&(
            <div>
              <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12,marginBottom:24}} className="fin-adm-grid">
                {[{label:'ARRECADADO',val:fmtBRL(finEnt),color:'#22c55e'},{label:'GASTO',val:fmtBRL(finSai),color:'var(--red)'},{label:'SALDO',val:fmtBRL(finEnt-finSai),color:'var(--text)'},{label:'META TOTAL',val:fmtBRL(finMetaTotal),color:'var(--gold)'}].map(t=>(
                  <div key={t.label} style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,padding:'18px 20px'}}>
                    <div style={{fontSize:'.63rem',fontWeight:700,textTransform:'uppercase',letterSpacing:'.1em',color:'var(--text3)',marginBottom:8}}>{t.label}</div>
                    <div style={{fontFamily:'Syne,sans-serif',fontSize:'1.5rem',fontWeight:800,color:t.color}}>{t.val}</div>
                  </div>
                ))}
              </div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18,flexWrap:'wrap',gap:10}}>
                <h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>💸 Movimentações</h3>
                <div style={{display:'flex',gap:8}}>
                  <button onClick={()=>openMovModal('entrada')} style={btnSt('success')}>+ Entrada</button>
                  <button onClick={()=>openMovModal('saida')} style={btnSt('danger')}>- Saída</button>
                </div>
              </div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden',marginBottom:28}}>
                {finMovs.map(m=>(
                  <Row key={m.id}>
                    <div style={{width:8,height:8,borderRadius:'50%',flexShrink:0,marginTop:6,background:m.tipo==='entrada'?'#22c55e':'var(--red)'}}/>
                    <div style={{flex:1}}>
                      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:100,background:m.tipo==='entrada'?'rgba(34,197,94,.12)':'rgba(232,25,44,.12)',color:m.tipo==='entrada'?'#22c55e':'var(--red-light)'}}>{m.tipo==='entrada'?'↑':'↓'} {m.tipo}</span>
                        <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--surface2)',color:'var(--text2)'}}>{m.categoria}</span>
                        <span style={{fontSize:'.7rem',color:'var(--text3)'}}>{m.data}</span>
                      </div>
                      <div style={{fontWeight:600,fontSize:'.9rem'}}>{m.descricao}</div>
                      {m.projeto_ref&&<div style={{fontSize:'.75rem',color:'var(--text3)',marginTop:2}}>📎 {m.projeto_ref}</div>}
                    </div>
                    <div style={{textAlign:'right',flexShrink:0}}>
                      <div style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:800,color:m.tipo==='entrada'?'#22c55e':'var(--red-light)',marginBottom:6}}>{m.tipo==='saida'?'-':'+'}{fmtBRL(m.valor)}</div>
                      <div style={{display:'flex',gap:6}}>
                        <button onClick={()=>openMovModal(m.tipo,m)} style={btnSt('secondary')}>✏️</button>
                        <button onClick={()=>delItem('financeiro',m.id,loadFin)} style={btnSt('danger')}>🗑</button>
                      </div>
                    </div>
                  </Row>
                ))}
                {finMovs.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma movimentação.</div>}
              </div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}><h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>🎯 Metas</h3><button onClick={()=>openMetaModal()} style={btnSt('primary')}>+ Nova meta</button></div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {finMetas.map(m=>(
                  <Row key={m.id}>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600,fontSize:'.9rem',marginBottom:3}}>{m.nome}</div>
                      {m.descricao&&<div style={{fontSize:'.78rem',color:'var(--text2)',marginBottom:4}}>{m.descricao}</div>}
                      <div style={{fontSize:'.78rem',color:'var(--text3)'}}>Meta: <strong style={{color:'var(--gold)'}}>{fmtBRL(m.meta)}</strong></div>
                    </div>
                    <div style={{display:'flex',gap:6}}>
                      <button onClick={()=>openMetaModal(m)} style={btnSt('secondary')}>✏️</button>
                      <button onClick={()=>delItem('metas_financeiras',m.id,loadFin)} style={btnSt('danger')}>🗑</button>
                    </div>
                  </Row>
                ))}
                {finMetas.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhuma meta.</div>}
              </div>
            </div>
          )}

          {/* ENQUETES */}
          {page==='enquetes'&&(
            <div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}><h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>🗳️ Enquetes</h3><button onClick={openEnqueteModal} style={btnSt('primary')}>+ Nova</button></div>
              {enquetes.map(e=>{
                const tot=e.enquete_opcoes?.reduce((a:number,o:any)=>a+o.votos,0)||0
                return(
                  <div key={e.id} style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,marginBottom:14,overflow:'hidden'}}>
                    <div style={{padding:'18px 20px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between',flexWrap:'wrap',gap:10}}>
                      <div><div style={{fontWeight:600,fontSize:'.9rem'}}>{e.pergunta}</div><div style={{fontSize:'.72rem',color:'var(--text3)',marginTop:3}}>{e.ativa?'🟢 Ativa':'🔴 Encerrada'} · {tot} votos</div></div>
                      <div style={{display:'flex',gap:8}}>
                        <button onClick={async()=>{await supabase.from('enquetes').update({ativa:!e.ativa}).eq('id',e.id);showToast('✅',e.ativa?'Encerrada.':'Reativada.');loadEnquetes()}} style={btnSt(e.ativa?'danger':'success')}>{e.ativa?'Encerrar':'Reativar'}</button>
                        <button onClick={()=>delItem('enquetes',e.id,loadEnquetes)} style={btnSt('danger')}>🗑</button>
                      </div>
                    </div>
                    <div style={{padding:'14px 20px'}}>
                      {(e.enquete_opcoes||[]).sort((a:any,b:any)=>a.ordem-b.ordem).map((o:any)=>{
                        const pct=tot>0?Math.round(o.votos/tot*100):0
                        return(<div key={o.id} style={{marginBottom:10}}>
                          <div style={{display:'flex',justifyContent:'space-between',fontSize:'.835rem',marginBottom:4}}><span>{o.texto}</span><span style={{fontWeight:700,color:'var(--red)'}}>{pct}% ({o.votos})</span></div>
                          <div style={{height:4,background:'var(--bg3)',borderRadius:100,overflow:'hidden'}}><div style={{height:'100%',borderRadius:100,background:'var(--red)',width:`${pct}%`}}/></div>
                        </div>)
                      })}
                    </div>
                  </div>
                )
              })}
              {enquetes.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)',background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12}}>Nenhuma enquete.</div>}
            </div>
          )}

          {/* EVENTOS */}
          {page==='eventos'&&(
            <div>
              <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:18}}><h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1.05rem',fontWeight:700}}>📅 Eventos</h3><button onClick={()=>openEventoModal()} style={btnSt('primary')}>+ Novo</button></div>
              <div style={{background:'var(--surface)',border:'1px solid var(--border)',borderRadius:12,overflow:'hidden'}}>
                {eventos.map(e=>{
                  const icons:Record<string,string>={evento:'🎉',prova:'📝',reuniao:'🤝',outro:'📌'}
                  return(
                    <Row key={e.id}>
                      <div style={{flex:1}}>
                        <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap'}}>
                          <span style={{fontSize:'.65rem',fontWeight:700,padding:'2px 8px',borderRadius:4,background:'var(--surface2)',color:'var(--text2)'}}>{icons[e.tipo]||'📌'} {e.tipo}</span>
                          <span style={{fontSize:'.75rem',color:'var(--red)',fontWeight:600}}>{e.data}</span>
                          {!e.publicado&&<span style={{fontSize:'.65rem',color:'var(--text3)'}}>🚫</span>}
                        </div>
                        <div style={{fontWeight:600,fontSize:'.9rem'}}>{e.titulo}</div>
                        {e.descricao&&<div style={{fontSize:'.835rem',color:'var(--text2)',marginTop:2}}>{e.descricao}</div>}
                      </div>
                      <div style={{display:'flex',gap:6}}>
                        <button onClick={()=>openEventoModal(e)} style={btnSt('secondary')}>✏️</button>
                        <button onClick={()=>delItem('eventos',e.id,loadEventos)} style={btnSt('danger')}>🗑</button>
                      </div>
                    </Row>
                  )
                })}
                {eventos.length===0&&<div style={{padding:32,textAlign:'center',color:'var(--text3)'}}>Nenhum evento.</div>}
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Modal */}
      {modal&&(
        <div onClick={e=>{if(e.target===e.currentTarget)closeModal()}} style={{position:'fixed',inset:0,background:'rgba(0,0,0,.88)',zIndex:2000,display:'flex',alignItems:'center',justifyContent:'center',padding:20,backdropFilter:'blur(8px)'}}>
          <div style={{background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:16,width:'100%',maxWidth:560,maxHeight:'85vh',overflowY:'auto'}}>
            <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'20px 24px',borderBottom:'1px solid var(--border)'}}>
              <h3 style={{fontFamily:'Syne,sans-serif',fontSize:'1rem',fontWeight:700}}>{modal.title}</h3>
              <button onClick={closeModal} style={{width:28,height:28,background:'transparent',border:'1px solid var(--border)',borderRadius:6,color:'var(--text2)',cursor:'pointer',fontSize:'.9rem'}}>✕</button>
            </div>
            <div style={{padding:24}}>{modal.body}</div>
            <div style={{padding:'16px 24px',borderTop:'1px solid var(--border)'}}>{modal.foot}</div>
          </div>
        </div>
      )}

      {/* Toast */}
      {toast&&(
        <div style={{position:'fixed',bottom:20,right:20,background:'var(--surface)',border:'1px solid rgba(232,25,44,.35)',borderRadius:10,padding:'12px 16px',display:'flex',alignItems:'center',gap:10,zIndex:5000,boxShadow:'0 8px 28px rgba(0,0,0,.5)',maxWidth:300}}>
          <span>{toast.icon}</span><span style={{fontSize:'.83rem',fontWeight:500}}>{toast.text}</span>
        </div>
      )}

      <style>{`
        .sidebar{transition:transform .3s ease;}
        @media(max-width:768px){
          .admin-main{margin-left:0!important;}
          .sidebar{transform:translateX(-100%);}
          .sidebar.open{transform:translateX(0)!important;}
          .burger{display:flex!important;}
          .fin-adm-grid{grid-template-columns:repeat(2,1fr)!important;}
        }
      `}</style>
    </div>
  )
}
