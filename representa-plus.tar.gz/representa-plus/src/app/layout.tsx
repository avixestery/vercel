import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Representa+ | Grêmio Estudantil — Ideal Batista Campos',
  description: 'O grêmio que representa você. Sua voz importa.',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>{children}</body>
    </html>
  )
}
