'use client'
import { useState } from 'react'
import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import FormsSection from '@/components/FormsSection'
import AnunciosSection from '@/components/AnunciosSection'
import ProjetosSection from '@/components/ProjetosSection'
import FinanceiroSection from '@/components/FinanceiroSection'
import CalendarioSection from '@/components/CalendarioSection'
import {
  EquipeSection,
  PollsSection,
  PrivacySection,
  ContactSection,
  Footer,
} from '@/components/OtherSections'

type Tab = 'ideas' | 'denuncia'

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('ideas')

  function handleOpenTab(tab: string) {
    setActiveTab(tab as Tab)
    setTimeout(() => {
      document.getElementById('ideias')?.scrollIntoView({ behavior: 'smooth' })
    }, 50)
  }

  return (
    <>
      <Navbar onOpenTab={handleOpenTab} />
      <main style={{ paddingTop: 64 }}>
        <Hero onOpenTab={handleOpenTab} />

        {/* Quick Actions */}
        <div style={{ borderTop: '1px solid var(--border)' }}>
          <div style={{ maxWidth: 1200, margin: '0 auto', padding: '56px 24px' }}>
            <div style={{ fontSize: '.7rem', fontWeight: 700, textTransform: 'uppercase', letterSpacing: '.12em', color: 'var(--red)', marginBottom: 8 }}>Ações rápidas</div>
            <h2 style={{ fontFamily: 'Syne, sans-serif', fontSize: 'clamp(1.8rem,3.5vw,2.7rem)', fontWeight: 800, lineHeight: 1.1, letterSpacing: '-.02em', marginBottom: 12 }}>O que você quer fazer?</h2>
            <p style={{ color: 'var(--text2)', fontSize: '.97rem', maxWidth: 500, fontWeight: 300, lineHeight: 1.7 }}>Um grêmio feito por alunos, para alunos. Sem burocracia. Só ação.</p>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit,minmax(240px,1fr))', gap: 14, marginTop: 36 }}>
              {[
                { href: '#ideias', icon: '🧠', title: 'Enviar ideia', desc: 'Compartilhe sugestões para melhorar a escola.', variant: 'red' },
                { href: '#ideias', icon: '🕵️', title: 'Denúncia anônima', desc: 'Fale com total segurança. 100% sigiloso.', variant: 'white', tab: 'denuncia' },
                { href: '#anuncios', icon: '📢', title: 'Anúncios', desc: 'Fique por dentro de tudo que está acontecendo.', variant: 'dark' },
                { href: '#votacao', icon: '🗳️', title: 'Votações', desc: 'Decida junto com o grêmio.', variant: 'gold' },
              ].map(c => (
                <a key={c.title} href={c.href}
                  onClick={c.tab ? () => handleOpenTab(c.tab!) : undefined}
                  style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 14, padding: 28, cursor: 'pointer', textDecoration: 'none', color: 'inherit', display: 'block', position: 'relative', overflow: 'hidden', transition: 'var(--t)' }}
                  onMouseEnter={e => { (e.currentTarget as HTMLElement).style.transform = 'translateY(-3px)' }}
                  onMouseLeave={e => { (e.currentTarget as HTMLElement).style.transform = 'none' }}>
                  <span style={{ fontSize: '1.9rem', marginBottom: 14, display: 'block' }}>{c.icon}</span>
                  <h3 style={{ fontFamily: 'Syne, sans-serif', fontSize: '1.1rem', fontWeight: 700, marginBottom: 6 }}>{c.title}</h3>
                  <p style={{ fontSize: '.855rem', color: 'var(--text2)', lineHeight: 1.6 }}>{c.desc}</p>
                  <span style={{ position: 'absolute', top: 20, right: 20, fontSize: '1rem', color: 'var(--text3)' }}>↗</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        <FormsSection activeTab={activeTab} setActiveTab={setActiveTab} />
        <AnunciosSection />
        <ProjetosSection />
        <FinanceiroSection />
        <CalendarioSection />
        <EquipeSection />
        <PollsSection />
        <PrivacySection onOpenTab={handleOpenTab} />
        <ContactSection />
      </main>
      <Footer />
    </>
  )
}
