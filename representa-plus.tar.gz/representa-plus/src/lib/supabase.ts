import { createClient } from '@supabase/supabase-js'

const SUPABASE_URL = 'https://qooqrmkhhnyziauwnhko.supabase.co'
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFvb3FybWtoaG55emlhdXduaGtvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU2ODA5MTcsImV4cCI6MjA5MTI1NjkxN30.avfhbhaMb1MLFvrByP5VRTFkj6f8ftVH4upEUzgY4uE'

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON)

export type Database = {
  ideias: { id: string; created_at: string; nome: string|null; categoria: string; texto: string; anonimo: boolean; status: string; resposta: string|null }
  denuncias: { id: string; created_at: string; categoria: string; texto: string; status: string; nota_interna: string|null }
  contatos: { id: string; created_at: string; nome: string; email: string|null; mensagem: string; respondido: boolean }
  anuncios: { id: string; created_at: string; titulo: string; descricao: string; categoria: string; destaque: boolean; publicado: boolean; autor: string }
  projetos: { id: string; created_at: string; nome: string; descricao: string; status: string; progresso: number; voluntarios: number; max_participantes: number; sem_participantes: boolean; ordem: number }
  enquetes: { id: string; created_at: string; pergunta: string; ativa: boolean; encerra_em: string|null }
  enquete_opcoes: { id: string; enquete_id: string; texto: string; votos: number; ordem: number }
  eventos: { id: string; created_at: string; titulo: string; descricao: string|null; data: string; tipo: string; publicado: boolean }
  financeiro: { id: string; created_at: string; tipo: string; descricao: string; valor: number; categoria: string; data: string; projeto_ref: string|null; publicado: boolean }
  metas_financeiras: { id: string; created_at: string; nome: string; meta: number; descricao: string|null; ativa: boolean }
}
